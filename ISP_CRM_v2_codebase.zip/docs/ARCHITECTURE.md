# ISP CRM V2 — Architecture Guide

## Folder Structure

```
isp-crm-backend/
│
├── .env                          # Environment variables (copy from .env.example)
├── .env.example                  # ← All variables documented here
├── package.json                  # V2 dependencies added (node-cron, puppeteer)
│
├── migrations/
│   ├── migrate.js                # V1 migration (unchanged — DO NOT MODIFY)
│   ├── migrate_v2.js             # ✅ V2 additive-only migration
│   └── rollback_v2.js            # ✅ Full V2 rollback (v1 safe)
│
├── seeds/
│   └── seed.js                   # Seed data (unchanged)
│
├── src/
│   ├── server.js                 # ✅ UPGRADED — mounts v1 + v2 + webhooks + crons
│   │
│   ├── config/
│   │   └── database.js           # DB pool (unchanged — shared by v1 & v2)
│   │
│   ├── controllers/              # V1 controllers (unchanged)
│   │   ├── auth.controller.js
│   │   ├── lead.controller.js
│   │   └── user.controller.js
│   │
│   ├── middleware/               # V1 middleware (unchanged)
│   │   ├── auth.middleware.js
│   │   ├── audit.middleware.js
│   │   ├── error.middleware.js
│   │   └── validate.middleware.js  # ✅ NEW — shared by v1 & v2
│   │
│   ├── models/
│   │   └── lead.model.js         # (unchanged)
│   │
│   ├── routes/
│   │   └── index.routes.js       # V1 routes (UNCHANGED)
│   │
│   └── utils/
│       ├── logger.js             # (unchanged)
│       └── response.js           # (unchanged)
│
└── src/v2/                       # ✅ ALL NEW — V2 MODULES
    │
    ├── routes/
    │   └── index.js              # V2 master router — all modules wired here
    │
    ├── controllers/
    │   ├── followup.controller.js  # Module 1: Call & Follow-Up
    │   ├── timeline.controller.js  # Module 2: Lead Timeline
    │   ├── settings.controller.js  # Module 3: Master Settings
    │   ├── permissions.controller.js # Module 4: Role Permissions
    │   ├── reports.controller.js   # Module 5: Reports & Analytics
    │   └── payment.controller.js   # Module 6: Payment Enhancement
    │
    ├── middleware/
    │   ├── featureFlag.middleware.js  # Module enable/disable guard
    │   └── authorize.middleware.js   # Enhanced RBAC + permission-level checks
    │
    ├── crons/
    │   └── index.js              # All 4 scheduled jobs registered here
    │
    └── webhooks/
        └── payment.webhook.js    # HMAC-verified payment gateway webhook
```

---

## API Reference — V2 Endpoints

All V2 endpoints require `Authorization: Bearer <JWT>` header.

### Module 1 — Call & Follow-Up

| Method | Endpoint | Access |
|--------|----------|--------|
| GET | `/api/v2/leads/:id/followups` | admin, sales, it, installation, accounts |
| POST | `/api/v2/leads/:id/followups` | admin, sales |
| PATCH | `/api/v2/leads/:id/followups/:fuId` | admin, sales |
| GET | `/api/v2/reports/call-performance` | admin, sales |

### Module 2 — Lead Timeline

| Method | Endpoint | Access |
|--------|----------|--------|
| GET | `/api/v2/leads/:id/timeline` | All roles |
| POST | `/api/v2/leads/:id/timeline` | admin, sales |
| POST | `/api/v2/leads/:id/timeline/attachments` | All roles |

### Module 3 — Master Settings (admin only)

| Method | Endpoint |
|--------|----------|
| GET/POST | `/api/v2/settings/custom-fields` |
| PATCH | `/api/v2/settings/custom-fields/:fieldId` |
| GET/POST | `/api/v2/settings/pipeline-stages` |
| GET/POST | `/api/v2/settings/scoring-rules` |
| GET/POST | `/api/v2/settings/assignment-rules` |
| GET | `/api/v2/settings/feature-flags` |
| PATCH | `/api/v2/settings/feature-flags/:flagKey` |

### Module 4 — Permissions (admin only)

| Method | Endpoint |
|--------|----------|
| GET | `/api/v2/permissions` |
| GET/POST | `/api/v2/permissions/roles/:role` |
| GET/POST | `/api/v2/permissions/module-access` |
| GET/PUT | `/api/v2/permissions/financial-flags/:userId` |

### Module 5 — Reports

| Method | Endpoint | Access |
|--------|----------|--------|
| GET | `/api/v2/reports/funnel` | reports:read |
| GET | `/api/v2/reports/revenue-forecast` | reports:read |
| GET | `/api/v2/reports/team-comparison` | reports:read |
| GET | `/api/v2/reports/export/pdf` | reports:export |

### Module 6 — Payments V2

| Method | Endpoint | Access |
|--------|----------|--------|
| GET | `/api/v2/payments` | payments:read |
| POST | `/api/v2/payments` | admin, accounts |
| GET/POST | `/api/v2/payments/commission-rules` | admin |
| GET | `/api/v2/payments/commissions` | financial flag |
| POST | `/api/v2/webhooks/payment` | Gateway (HMAC) |

---

## Cron Jobs

| Schedule | Job | Timezone |
|----------|-----|----------|
| Every 5 min | 5-minute follow-up reminder notifications | IST |
| Every 5 min | Mark 30-min overdue follow-ups | IST |
| Daily 02:00 | Pre-compute revenue forecast cache | IST |
| Daily 09:00 | Payment reminder notifications | IST |

---

## Feature Flags

Manage via `PATCH /api/v2/settings/feature-flags/:flagKey`:

```json
{ "is_enabled": true, "enabled_for": ["role:admin", "user:uuid-here"] }
```

Default flags seeded: `MODULE_FOLLOWUPS`, `MODULE_TIMELINE`, `MODULE_SETTINGS`, `MODULE_PERMISSIONS`, `MODULE_REPORTS`, `MODULE_PAYMENTS_V2`

---

## Migration & Rollback Commands

```bash
# Run V2 migration (safe to re-run — idempotent)
node migrations/migrate_v2.js

# Dry-run rollback (see what would be dropped, no changes)
DRY_RUN=true node migrations/rollback_v2.js

# Full rollback (production requires CONFIRM_ROLLBACK=true)
node migrations/rollback_v2.js

# npm shortcuts
npm run migrate:v2
npm run rollback:v2
npm run rollback:v2:dry
```

---

## Deployment — Free Hosting

### Option A: Railway.app (Recommended — Free Tier)

1. **Push to GitHub** your repository
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Add **PostgreSQL** plugin (Railway provides one free)
4. Set environment variables in Railway dashboard (copy from `.env.example`)
5. Railway auto-detects Node.js and runs `npm start`
6. Run migrations via Railway Shell:
   ```
   npm run migrate:all
   ```

### Option B: Render.com

1. Create account at [render.com](https://render.com)
2. New → Web Service → Connect GitHub repo
3. Build command: `npm install`
4. Start command: `node src/server.js`
5. Add PostgreSQL database (Render free tier)
6. Set all env vars in Render dashboard
7. Open Shell → `npm run migrate:all`

### Option C: Fly.io

```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Login and launch
fly auth login
fly launch --name isp-crm-api

# Add PostgreSQL
fly postgres create --name isp-crm-db
fly postgres attach --app isp-crm-api isp-crm-db

# Set secrets
fly secrets set JWT_SECRET=... WEBHOOK_SECRET=...

# Deploy
fly deploy

# Run migrations
fly ssh console -C "node migrations/migrate_v2.js"
```

### Production Checklist

- [ ] `NODE_ENV=production`
- [ ] Strong `JWT_SECRET` (64+ chars)
- [ ] `WEBHOOK_SECRET` configured and shared with payment gateway
- [ ] `DB_SSL=true` for production PostgreSQL
- [ ] `CORS_ORIGIN` set to actual frontend domain
- [ ] `CONFIRM_ROLLBACK` NOT set (prevents accidental rollback)
- [ ] Puppeteer `--no-sandbox` flag set (Linux server requirement)
- [ ] Log directory is writable
- [ ] Uploads directory is writable and persistent (use cloud storage in prod)

---

## Database Schema — V2 Tables

```
feature_flags              ← Module enable/disable
follow_ups                 ← Call & follow-up tracking
lead_activities            ← Audit trail (populated by PG trigger)
activity_attachments       ← Files attached to timeline events
custom_field_definitions   ← Tenant-defined lead fields
lead_custom_field_values   ← Values for custom fields per lead
pipeline_stages            ← Visual pipeline configuration
lead_scoring_rules         ← Auto-scoring configuration
assignment_rules           ← Lead assignment automation
permissions                ← Atomic permission registry
role_permissions           ← Role ↔ permission matrix
module_access              ← Module-level access flags per role
financial_access_flags     ← Per-user financial data access
payment_transactions       ← Enhanced payment ledger (idempotent)
commission_rules           ← Configurable commission rates
commissions                ← Calculated commission records
report_cache               ← Pre-computed report payloads (TTL)
schema_migrations_v2       ← Migration tracking for v2
```

All tables use `IF NOT EXISTS`, all FK constraints reference existing v1 tables (`leads`, `users`), and zero v1 columns are modified.
