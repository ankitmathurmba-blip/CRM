/**
 * permissions.controller.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Role Permissions Module — Controller
 */

const { query } = require('../../config/database');
const response  = require('../../utils/response');
const logger    = require('../../utils/logger');

// ── All permissions ───────────────────────────────────────────────────────────
const listPermissions = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM permissions ORDER BY module, action');
    return response.success(res, rows, 'Permissions fetched');
  } catch (err) { next(err); }
};

// ── Role permission matrix ────────────────────────────────────────────────────
const getRolePermissions = async (req, res, next) => {
  try {
    const { role } = req.params;
    const { rows } = await query(
      `SELECT p.module, p.action, p.description, rp.granted
         FROM permissions p
         LEFT JOIN role_permissions rp ON rp.permission_id = p.id AND rp.role = $1
        ORDER BY p.module, p.action`,
      [role]
    );
    return response.success(res, rows, `Permissions for role: ${role}`);
  } catch (err) { next(err); }
};

// ── Grant/revoke permission ───────────────────────────────────────────────────
const setRolePermission = async (req, res, next) => {
  try {
    const { role }                  = req.params;
    const { permission_id, granted } = req.body;

    const { rows } = await query(
      `INSERT INTO role_permissions (role, permission_id, granted, granted_by)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (role, permission_id) DO UPDATE
         SET granted = $3, granted_by = $4
       RETURNING *`,
      [role, permission_id, granted !== false, req.user.id]
    );

    logger.info('[Permissions] Role permission set', { role, permission_id, granted });
    return response.success(res, rows[0], 'Permission updated');
  } catch (err) { next(err); }
};

// ── Module access ─────────────────────────────────────────────────────────────
const getModuleAccess = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM module_access ORDER BY role, module');
    return response.success(res, rows, 'Module access fetched');
  } catch (err) { next(err); }
};

const setModuleAccess = async (req, res, next) => {
  try {
    const { role, module: moduleName, can_access } = req.body;
    const { rows } = await query(
      `INSERT INTO module_access (role, module, can_access, updated_by)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (role, module) DO UPDATE
         SET can_access = $3, updated_by = $4, updated_at = NOW()
       RETURNING *`,
      [role, moduleName, can_access, req.user.id]
    );
    return response.success(res, rows[0], 'Module access updated');
  } catch (err) { next(err); }
};

// ── Financial access flags ────────────────────────────────────────────────────
const getFinancialFlags = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { rows } = await query(
      'SELECT * FROM financial_access_flags WHERE user_id = $1',
      [userId]
    );
    return response.success(res, rows[0] || null, 'Financial flags fetched');
  } catch (err) { next(err); }
};

const setFinancialFlags = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { can_view_revenue, can_view_commissions, can_export_payments, can_approve_refunds } = req.body;

    const { rows } = await query(
      `INSERT INTO financial_access_flags
         (user_id, can_view_revenue, can_view_commissions, can_export_payments, can_approve_refunds, updated_by)
       VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (user_id) DO UPDATE
         SET can_view_revenue     = COALESCE($2, financial_access_flags.can_view_revenue),
             can_view_commissions = COALESCE($3, financial_access_flags.can_view_commissions),
             can_export_payments  = COALESCE($4, financial_access_flags.can_export_payments),
             can_approve_refunds  = COALESCE($5, financial_access_flags.can_approve_refunds),
             updated_by           = $6,
             updated_at           = NOW()
       RETURNING *`,
      [userId, can_view_revenue, can_view_commissions, can_export_payments, can_approve_refunds, req.user.id]
    );

    logger.info('[Permissions] Financial flags updated', { userId });
    return response.success(res, rows[0], 'Financial access flags updated');
  } catch (err) { next(err); }
};

module.exports = {
  listPermissions, getRolePermissions, setRolePermission,
  getModuleAccess, setModuleAccess,
  getFinancialFlags, setFinancialFlags,
};
