/**
 * timeline.controller.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Lead Timeline Module — Controller
 *
 * Endpoints:
 *   GET  /api/v2/leads/:id/timeline
 *   POST /api/v2/leads/:id/timeline          (manual activity note)
 *   POST /api/v2/leads/:id/timeline/attachments
 */

const path     = require('path');
const fs       = require('fs');
const { query, paginatedQuery } = require('../../config/database');
const response = require('../../utils/response');
const logger   = require('../../utils/logger');

// ── Get lead timeline ─────────────────────────────────────────────────────────
const getTimeline = async (req, res, next) => {
  try {
    const { id: leadId }     = req.params;
    const { page = 1, limit = 30, type } = req.query;

    const conds  = ['la.lead_id = $1'];
    const params = [leadId];
    let   idx    = 2;

    if (type) {
      conds.push(`la.activity_type = $${idx++}`);
      params.push(type);
    }

    const where = conds.join(' AND ');
    const base  = `
      SELECT
        la.*,
        u.name         AS triggered_by_name,
        u.role         AS triggered_by_role,
        COALESCE(
          json_agg(aa.*) FILTER (WHERE aa.id IS NOT NULL),
          '[]'
        )              AS attachments
      FROM lead_activities la
      LEFT JOIN users u  ON la.triggered_by = u.id
      LEFT JOIN activity_attachments aa ON aa.activity_id = la.id
      WHERE ${where}
      GROUP BY la.id, u.name, u.role
      ORDER BY la.created_at DESC
    `;

    const result = await paginatedQuery(base, params, parseInt(page, 10), parseInt(limit, 10));
    return response.paginated(res, result.rows, result.pagination, 'Timeline fetched');
  } catch (err) {
    next(err);
  }
};

// ── Add manual note to timeline ───────────────────────────────────────────────
const addNote = async (req, res, next) => {
  try {
    const { id: leadId } = req.params;
    const { title, description } = req.body;

    const { rows } = await query(
      `INSERT INTO lead_activities
         (lead_id, triggered_by, activity_type, title, description, ip_address, user_agent)
       VALUES ($1,$2,'note_added',$3,$4,$5::inet,$6)
       RETURNING *`,
      [
        leadId,
        req.user.id,
        title || 'Note added',
        description,
        req.ip,
        req.headers['user-agent']?.substring(0, 500),
      ]
    );

    return response.created(res, rows[0], 'Note added to timeline');
  } catch (err) {
    next(err);
  }
};

// ── Upload attachment to an activity ─────────────────────────────────────────
const addAttachment = async (req, res, next) => {
  try {
    const { id: leadId } = req.params;
    const { activityId } = req.body;

    if (!req.file) return response.badRequest(res, 'No file provided');

    const { rows } = await query(
      `INSERT INTO activity_attachments
         (activity_id, lead_id, uploaded_by, file_name, file_url, file_size, mime_type)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       RETURNING *`,
      [
        activityId,
        leadId,
        req.user.id,
        req.file.originalname,
        `/uploads/${req.file.filename}`,
        req.file.size,
        req.file.mimetype,
      ]
    );

    return response.created(res, rows[0], 'Attachment uploaded');
  } catch (err) {
    next(err);
  }
};

module.exports = { getTimeline, addNote, addAttachment };
