/**
 * payment.controller.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Payment Enhancement Module — Controller
 *
 * Endpoints:
 *   GET  /api/v2/payments
 *   POST /api/v2/payments
 *   GET  /api/v2/payments/:txnId
 *   POST /api/v2/webhooks/payment           ← HMAC SHA256 verified, idempotent
 *   GET  /api/v2/commissions
 *   POST /api/v2/commissions/rules
 */

const crypto   = require('crypto');
const { query, withTransaction } = require('../../config/database');
const response = require('../../utils/response');
const logger   = require('../../utils/logger');

// ── HMAC SHA256 Signature Verification ────────────────────────────────────────
const verifyWebhookSignature = (rawBody, signature, secret) => {
  const expected = crypto
    .createHmac('sha256', secret)
    .update(rawBody)
    .digest('hex');

  // Timing-safe comparison
  const sig = Buffer.from(signature.replace(/^sha256=/, ''), 'hex');
  const exp = Buffer.from(expected, 'hex');

  if (sig.length !== exp.length) return false;
  return crypto.timingSafeEqual(sig, exp);
};

// ── List payment transactions ─────────────────────────────────────────────────
const listPayments = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, lead_id, status, from, to } = req.query;

    const conds  = [];
    const params = [];
    let   idx    = 1;

    if (lead_id) { conds.push(`pt.lead_id = $${idx++}`);              params.push(lead_id); }
    if (status)  { conds.push(`pt.txn_status = $${idx++}`);           params.push(status); }
    if (from)    { conds.push(`pt.created_at >= $${idx++}`);          params.push(from); }
    if (to)      { conds.push(`pt.created_at <= $${idx++}`);          params.push(to); }

    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : '';
    const base  = `
      SELECT pt.*, l.customer_name, l.mobile, u.name AS recorded_by_name
        FROM payment_transactions pt
        JOIN leads l ON pt.lead_id = l.id
        LEFT JOIN users u ON pt.recorded_by = u.id
        ${where}
        ORDER BY pt.created_at DESC
    `;

    const { paginatedQuery } = require('../../config/database');
    const result = await paginatedQuery(base, params, parseInt(page, 10), parseInt(limit, 10));
    return response.paginated(res, result.rows, result.pagination, 'Payments fetched');
  } catch (err) { next(err); }
};

// ── Record a new payment transaction ─────────────────────────────────────────
const createPayment = async (req, res, next) => {
  try {
    const {
      lead_id, amount, payment_mode, gateway_txn_id, notes,
      idempotency_key,
    } = req.body;

    // Idempotency check
    if (idempotency_key) {
      const { rows: dup } = await query(
        'SELECT id FROM payment_transactions WHERE idempotency_key = $1',
        [idempotency_key]
      );
      if (dup.length) {
        return response.success(res, { id: dup[0].id }, 'Duplicate — returning existing transaction');
      }
    }

    const result = await withTransaction(async (client) => {
      // Create transaction
      const { rows: txn } = await client.query(
        `INSERT INTO payment_transactions
           (lead_id, recorded_by, amount, payment_mode, gateway_txn_id,
            txn_status, idempotency_key, notes)
         VALUES ($1,$2,$3,$4,$5,'success',$6,$7) RETURNING *`,
        [lead_id, req.user.id, amount, payment_mode, gateway_txn_id, idempotency_key, notes]
      );

      // Calculate commissions based on active rules
      const { rows: rules } = await client.query(
        `SELECT * FROM commission_rules
          WHERE is_active = TRUE AND applies_to_role = $1
          ORDER BY priority DESC LIMIT 1`,
        [req.user.role]
      );

      if (rules.length) {
        const rule = rules[0];
        const commAmt = rule.commission_type === 'percentage'
          ? (parseFloat(amount) * parseFloat(rule.rate)) / 100
          : parseFloat(rule.rate);

        await client.query(
          `INSERT INTO commissions
             (transaction_id, lead_id, user_id, rule_id, commission_type, rate, base_amount, commission_amt)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [txn[0].id, lead_id, req.user.id, rule.id, rule.commission_type, rule.rate, amount, commAmt]
        );
      }

      // Log activity
      await client.query(
        `INSERT INTO lead_activities (lead_id, triggered_by, activity_type, title, new_value)
         VALUES ($1,$2,'payment_received','Payment recorded',$3)`,
        [lead_id, req.user.id, JSON.stringify({ amount, mode: payment_mode, txn_id: txn[0].id })]
      );

      return txn[0];
    });

    logger.info('[Payment] Transaction created', { id: result.id, amount, lead_id });
    return response.created(res, result, 'Payment recorded');
  } catch (err) { next(err); }
};

// ── Payment webhook (HMAC SHA256 verified, idempotent) ─────────────────────────
const webhookHandler = async (req, res, next) => {
  try {
    const signature = req.headers['x-webhook-signature'] || req.headers['x-hub-signature-256'] || '';
    const rawBody   = req.rawBody; // Set by express.raw() middleware on this route

    if (!rawBody) {
      logger.warn('[Webhook] No raw body captured');
      return res.status(400).json({ error: 'Invalid request' });
    }

    const secret = process.env.WEBHOOK_SECRET;
    if (!secret) {
      logger.error('[Webhook] WEBHOOK_SECRET not configured');
      return res.status(500).json({ error: 'Webhook not configured' });
    }

    if (!verifyWebhookSignature(rawBody, signature, secret)) {
      logger.warn('[Webhook] Invalid signature', { signature: signature?.slice(0, 20) });
      return res.status(401).json({ error: 'Invalid signature' });
    }

    const payload = JSON.parse(rawBody.toString('utf8'));
    const {
      event,
      transaction_id: gatewayTxnId,
      idempotency_key,
      lead_id,
      amount,
      status,
      gateway_response,
    } = payload;

    logger.info('[Webhook] Received', { event, gatewayTxnId });

    // ── Idempotency guard ─────────────────────────────────────────────────────
    if (idempotency_key) {
      const { rows: existing } = await query(
        'SELECT id FROM payment_transactions WHERE idempotency_key = $1',
        [idempotency_key]
      );
      if (existing.length) {
        logger.info('[Webhook] Duplicate event ignored', { idempotency_key });
        return res.status(200).json({ received: true, duplicate: true });
      }
    }

    // ── Process event ─────────────────────────────────────────────────────────
    await withTransaction(async (client) => {
      if (event === 'payment.success') {
        await client.query(
          `INSERT INTO payment_transactions
             (lead_id, amount, payment_mode, gateway_txn_id, txn_status,
              idempotency_key, gateway_response, webhook_received_at, webhook_signature)
           VALUES ($1,$2,'gateway',$3,'success',$4,$5::jsonb,NOW(),$6)
           ON CONFLICT (idempotency_key) DO NOTHING`,
          [lead_id, amount, gatewayTxnId, idempotency_key, JSON.stringify(gateway_response), signature]
        );
      } else if (event === 'payment.failed') {
        await client.query(
          `UPDATE payment_transactions SET txn_status = 'failed', updated_at = NOW()
            WHERE gateway_txn_id = $1`,
          [gatewayTxnId]
        );
      } else if (event === 'payment.refunded') {
        await client.query(
          `UPDATE payment_transactions SET txn_status = 'refunded', updated_at = NOW()
            WHERE gateway_txn_id = $1`,
          [gatewayTxnId]
        );
      }
    });

    return res.status(200).json({ received: true });
  } catch (err) {
    logger.error('[Webhook] Processing error', { error: err.message });
    // Always return 200 to avoid gateway retries flooding us
    return res.status(200).json({ received: true, error: 'Processing failed — will retry' });
  }
};

// ── Commission rules ──────────────────────────────────────────────────────────
const listCommissionRules = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM commission_rules ORDER BY created_at DESC');
    return response.success(res, rows, 'Commission rules fetched');
  } catch (err) { next(err); }
};

const createCommissionRule = async (req, res, next) => {
  try {
    const { name, applies_to_role, commission_type, rate, min_amount, max_amount, package_id } = req.body;
    const { rows } = await query(
      `INSERT INTO commission_rules (name, applies_to_role, commission_type, rate, min_amount, max_amount, package_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [name, applies_to_role || 'sales', commission_type || 'percentage', rate, min_amount, max_amount, package_id]
    );
    return response.created(res, rows[0], 'Commission rule created');
  } catch (err) { next(err); }
};

// ── View commissions ──────────────────────────────────────────────────────────
const listCommissions = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, user_id, status } = req.query;

    // Non-admin can only see their own commissions
    const resolvedUserId = req.user.role !== 'admin' ? req.user.id : (user_id || null);

    const conds  = [];
    const params = [];
    let   idx    = 1;

    if (resolvedUserId) { conds.push(`c.user_id = $${idx++}`);  params.push(resolvedUserId); }
    if (status)          { conds.push(`c.status = $${idx++}`); params.push(status); }

    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : '';
    const base  = `
      SELECT c.*, u.name AS user_name, l.customer_name
        FROM commissions c
        JOIN users u ON c.user_id = u.id
        JOIN leads l ON c.lead_id = l.id
        ${where}
        ORDER BY c.created_at DESC
    `;

    const { paginatedQuery } = require('../../config/database');
    const result = await paginatedQuery(base, params, parseInt(page, 10), parseInt(limit, 10));
    return response.paginated(res, result.rows, result.pagination, 'Commissions fetched');
  } catch (err) { next(err); }
};

module.exports = {
  listPayments, createPayment, webhookHandler,
  listCommissionRules, createCommissionRule, listCommissions,
};
