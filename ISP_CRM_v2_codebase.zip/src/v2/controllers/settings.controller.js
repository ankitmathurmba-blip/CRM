/**
 * settings.controller.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Master Settings Module — Controller
 *
 * Covers: custom fields, pipeline stages, scoring rules, assignment rules
 */

const { query, withTransaction } = require('../../config/database');
const response = require('../../utils/response');
const logger   = require('../../utils/logger');

// ─── CUSTOM FIELD DEFINITIONS ────────────────────────────────────────────────

const listCustomFields = async (req, res, next) => {
  try {
    const { entity_type = 'lead', active_only = 'true' } = req.query;
    const { rows } = await query(
      `SELECT * FROM custom_field_definitions
        WHERE entity_type = $1
          AND ($2::boolean = FALSE OR is_active = TRUE)
        ORDER BY sort_order ASC, created_at ASC`,
      [entity_type, active_only === 'true']
    );
    return response.success(res, rows, 'Custom fields fetched');
  } catch (err) { next(err); }
};

const createCustomField = async (req, res, next) => {
  try {
    const { entity_type = 'lead', field_key, field_label, field_type = 'text', options, is_required, sort_order } = req.body;
    const { rows } = await query(
      `INSERT INTO custom_field_definitions
         (entity_type, field_key, field_label, field_type, options, is_required, sort_order, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [entity_type, field_key, field_label, field_type, options ? JSON.stringify(options) : null, is_required || false, sort_order || 0, req.user.id]
    );
    logger.info('[Settings] Custom field created', { id: rows[0].id, field_key });
    return response.created(res, rows[0], 'Custom field created');
  } catch (err) { next(err); }
};

const updateCustomField = async (req, res, next) => {
  try {
    const { fieldId } = req.params;
    const { field_label, options, is_required, is_active, sort_order } = req.body;
    const { rows } = await query(
      `UPDATE custom_field_definitions
         SET field_label = COALESCE($1, field_label),
             options     = COALESCE($2::jsonb, options),
             is_required = COALESCE($3, is_required),
             is_active   = COALESCE($4, is_active),
             sort_order  = COALESCE($5, sort_order),
             updated_at  = NOW()
       WHERE id = $6 RETURNING *`,
      [field_label, options ? JSON.stringify(options) : null, is_required, is_active, sort_order, fieldId]
    );
    if (!rows.length) return response.notFound(res, 'Custom field not found');
    return response.success(res, rows[0], 'Custom field updated');
  } catch (err) { next(err); }
};

// ─── LEAD CUSTOM FIELD VALUES ────────────────────────────────────────────────

const getLeadCustomValues = async (req, res, next) => {
  try {
    const { leadId } = req.params;
    const { rows } = await query(
      `SELECT lcfv.*, cfd.field_label, cfd.field_key, cfd.field_type
         FROM lead_custom_field_values lcfv
         JOIN custom_field_definitions cfd ON lcfv.field_def_id = cfd.id
        WHERE lcfv.lead_id = $1 ORDER BY cfd.sort_order`,
      [leadId]
    );
    return response.success(res, rows, 'Custom field values fetched');
  } catch (err) { next(err); }
};

const upsertLeadCustomValue = async (req, res, next) => {
  try {
    const { leadId } = req.params;
    const { field_def_id, value_text, value_number, value_boolean, value_date, value_json } = req.body;
    const { rows } = await query(
      `INSERT INTO lead_custom_field_values
         (lead_id, field_def_id, value_text, value_number, value_boolean, value_date, value_json)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (lead_id, field_def_id) DO UPDATE
         SET value_text    = EXCLUDED.value_text,
             value_number  = EXCLUDED.value_number,
             value_boolean = EXCLUDED.value_boolean,
             value_date    = EXCLUDED.value_date,
             value_json    = EXCLUDED.value_json,
             updated_at    = NOW()
       RETURNING *`,
      [leadId, field_def_id, value_text, value_number, value_boolean, value_date, value_json ? JSON.stringify(value_json) : null]
    );
    return response.success(res, rows[0], 'Custom field value saved');
  } catch (err) { next(err); }
};

// ─── PIPELINE STAGES ─────────────────────────────────────────────────────────

const listStages = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM pipeline_stages WHERE is_active = TRUE ORDER BY sort_order ASC');
    return response.success(res, rows, 'Pipeline stages fetched');
  } catch (err) { next(err); }
};

const createStage = async (req, res, next) => {
  try {
    const { name, description, color, sort_order } = req.body;
    const { rows } = await query(
      'INSERT INTO pipeline_stages (name, description, color, sort_order) VALUES ($1,$2,$3,$4) RETURNING *',
      [name, description, color || '#6366f1', sort_order || 0]
    );
    return response.created(res, rows[0], 'Pipeline stage created');
  } catch (err) { next(err); }
};

// ─── SCORING RULES ────────────────────────────────────────────────────────────

const listScoringRules = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM lead_scoring_rules WHERE is_active = TRUE ORDER BY score_delta DESC');
    return response.success(res, rows, 'Scoring rules fetched');
  } catch (err) { next(err); }
};

const createScoringRule = async (req, res, next) => {
  try {
    const { rule_name, field_key, operator, value, score_delta } = req.body;
    const { rows } = await query(
      'INSERT INTO lead_scoring_rules (rule_name, field_key, operator, value, score_delta) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [rule_name, field_key, operator, JSON.stringify(value), score_delta]
    );
    return response.created(res, rows[0], 'Scoring rule created');
  } catch (err) { next(err); }
};

// ─── ASSIGNMENT RULES ─────────────────────────────────────────────────────────

const listAssignmentRules = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM assignment_rules WHERE is_active = TRUE ORDER BY priority ASC');
    return response.success(res, rows, 'Assignment rules fetched');
  } catch (err) { next(err); }
};

const createAssignmentRule = async (req, res, next) => {
  try {
    const { rule_name, conditions, assign_to_role, assign_to_user, strategy, priority } = req.body;
    const { rows } = await query(
      `INSERT INTO assignment_rules (rule_name, conditions, assign_to_role, assign_to_user, strategy, priority)
       VALUES ($1,$2::jsonb,$3,$4,$5,$6) RETURNING *`,
      [rule_name, JSON.stringify(conditions || {}), assign_to_role, assign_to_user, strategy || 'round_robin', priority || 0]
    );
    return response.created(res, rows[0], 'Assignment rule created');
  } catch (err) { next(err); }
};

// ─── FEATURE FLAGS MANAGEMENT ────────────────────────────────────────────────

const listFeatureFlags = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM feature_flags ORDER BY flag_key');
    return response.success(res, rows, 'Feature flags fetched');
  } catch (err) { next(err); }
};

const updateFeatureFlag = async (req, res, next) => {
  try {
    const { flagKey } = req.params;
    const { is_enabled, enabled_for } = req.body;

    const { rows } = await query(
      `UPDATE feature_flags
         SET is_enabled  = COALESCE($1, is_enabled),
             enabled_for = COALESCE($2::jsonb, enabled_for),
             updated_at  = NOW()
       WHERE flag_key = $3 RETURNING *`,
      [is_enabled, enabled_for ? JSON.stringify(enabled_for) : null, flagKey]
    );
    if (!rows.length) return response.notFound(res, 'Feature flag not found');

    // Invalidate cache
    const { invalidateFlagCache } = require('../middleware/featureFlag.middleware');
    invalidateFlagCache();

    logger.info('[Settings] Feature flag updated', { flagKey, is_enabled });
    return response.success(res, rows[0], 'Feature flag updated');
  } catch (err) { next(err); }
};

module.exports = {
  listCustomFields, createCustomField, updateCustomField,
  getLeadCustomValues, upsertLeadCustomValue,
  listStages, createStage,
  listScoringRules, createScoringRule,
  listAssignmentRules, createAssignmentRule,
  listFeatureFlags, updateFeatureFlag,
};
