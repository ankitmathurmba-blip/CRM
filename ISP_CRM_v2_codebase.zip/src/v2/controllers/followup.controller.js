/**
 * followup.controller.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Call & Follow-Up Module — Controller
 *
 * Endpoints handled:
 *   GET    /api/v2/leads/:id/followups
 *   POST   /api/v2/leads/:id/followups
 *   PATCH  /api/v2/leads/:id/followups/:fuId
 *   GET    /api/v2/reports/call-performance
 */

const { query, withTransaction, paginatedQuery } = require('../../config/database');
const response = require('../../utils/response');
const logger   = require('../../utils/logger');

// ── Helper: verify lead exists ────────────────────────────────────────────────
const assertLeadExists = async (leadId) => {
  const { rows } = await query('SELECT id FROM leads WHERE id = $1', [leadId]);
  return rows.length > 0;
};

// ── List follow-ups for a lead ────────────────────────────────────────────────
const list = async (req, res, next) => {
  try {
    const { id: leadId } = req.params;
    const { page = 1, limit = 20, status } = req.query;

    if (!(await assertLeadExists(leadId))) {
      return response.notFound(res, 'Lead not found');
    }

    const conds  = ['fu.lead_id = $1', 'fu.is_deleted = FALSE'];
    const params = [leadId];
    let   idx    = 2;

    if (status) {
      conds.push(`fu.status = $${idx++}`);
      params.push(status);
    }

    const where = conds.join(' AND ');
    const base  = `
      SELECT
        fu.*,
        u_assigned.name  AS assigned_to_name,
        u_created.name   AS created_by_name
      FROM follow_ups fu
      JOIN users u_assigned ON fu.assigned_to = u_assigned.id
      JOIN users u_created  ON fu.created_by  = u_created.id
      WHERE ${where}
      ORDER BY fu.scheduled_at ASC
    `;

    const result = await paginatedQuery(base, params, parseInt(page, 10), parseInt(limit, 10));
    return response.paginated(res, result.rows, result.pagination, 'Follow-ups fetched');
  } catch (err) {
    next(err);
  }
};

// ── Create follow-up ──────────────────────────────────────────────────────────
const create = async (req, res, next) => {
  try {
    const { id: leadId }  = req.params;
    const {
      followup_type = 'call',
      scheduled_at,
      assigned_to,
      notes,
      next_action,
    } = req.body;

    if (!(await assertLeadExists(leadId))) {
      return response.notFound(res, 'Lead not found');
    }

    const assignTo = assigned_to || req.user.id;

    const { rows } = await query(
      `INSERT INTO follow_ups
         (lead_id, assigned_to, created_by, followup_type, scheduled_at, notes, next_action)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       RETURNING *`,
      [leadId, assignTo, req.user.id, followup_type, scheduled_at, notes, next_action]
    );

    // Log activity
    await query(
      `INSERT INTO lead_activities
         (lead_id, triggered_by, activity_type, title, new_value)
       VALUES ($1,$2,'followup_scheduled',$3,$4)`,
      [
        leadId,
        req.user.id,
        `Follow-up scheduled for ${new Date(scheduled_at).toLocaleString('en-IN')}`,
        JSON.stringify({ followup_id: rows[0].id, type: followup_type }),
      ]
    );

    logger.info('[FollowUp] Created', { id: rows[0].id, leadId, by: req.user.id });
    return response.created(res, rows[0], 'Follow-up scheduled');
  } catch (err) {
    next(err);
  }
};

// ── Update / complete / reschedule ────────────────────────────────────────────
const update = async (req, res, next) => {
  try {
    const { id: leadId, fuId } = req.params;
    const { status, outcome, duration_minutes, completed_at, reschedule_to, reschedule_reason } = req.body;

    const { rows: existing } = await query(
      'SELECT * FROM follow_ups WHERE id = $1 AND lead_id = $2 AND is_deleted = FALSE',
      [fuId, leadId]
    );
    if (!existing.length) return response.notFound(res, 'Follow-up not found');

    const fu = existing[0];

    // Auto-reschedule logic
    if (status === 'rescheduled' && reschedule_to) {
      return await withTransaction(async (client) => {
        // Mark original as rescheduled
        await client.query(
          `UPDATE follow_ups
             SET status = 'rescheduled', reschedule_reason = $1, updated_at = NOW()
           WHERE id = $2`,
          [reschedule_reason, fuId]
        );

        // Create new follow-up linked to original
        const { rows: newFu } = await client.query(
          `INSERT INTO follow_ups
             (lead_id, assigned_to, created_by, followup_type, scheduled_at,
              notes, rescheduled_from, reschedule_count)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
           RETURNING *`,
          [
            leadId, fu.assigned_to, req.user.id, fu.followup_type, reschedule_to,
            fu.notes, fuId, fu.reschedule_count + 1,
          ]
        );

        logger.info('[FollowUp] Rescheduled', { original: fuId, new: newFu[0].id });
        return response.success(res, newFu[0], 'Follow-up rescheduled');
      });
    }

    // Normal update
    const { rows } = await query(
      `UPDATE follow_ups
         SET status           = COALESCE($1, status),
             outcome          = COALESCE($2, outcome),
             duration_minutes = COALESCE($3, duration_minutes),
             completed_at     = COALESCE($4, completed_at),
             updated_at       = NOW()
       WHERE id = $5
       RETURNING *`,
      [status, outcome, duration_minutes, completed_at, fuId]
    );

    return response.success(res, rows[0], 'Follow-up updated');
  } catch (err) {
    next(err);
  }
};

// ── Call performance report ───────────────────────────────────────────────────
const callPerformanceReport = async (req, res, next) => {
  try {
    const { from = new Date(Date.now() - 30 * 86400000).toISOString(), to = new Date().toISOString() } = req.query;

    const { rows } = await query(
      `SELECT
          u.id                                              AS user_id,
          u.name                                            AS user_name,
          u.role,
          COUNT(fu.id)                                      AS total_followups,
          COUNT(fu.id) FILTER (WHERE fu.status = 'completed') AS completed,
          COUNT(fu.id) FILTER (WHERE fu.status = 'overdue')   AS overdue,
          COUNT(fu.id) FILTER (WHERE fu.status = 'rescheduled') AS rescheduled,
          ROUND(AVG(fu.duration_minutes) FILTER (WHERE fu.status = 'completed'), 1) AS avg_duration_min,
          ROUND(
            100.0 * COUNT(fu.id) FILTER (WHERE fu.status = 'completed')
                  / NULLIF(COUNT(fu.id), 0), 2
          )                                                 AS completion_rate_pct
        FROM users u
        LEFT JOIN follow_ups fu
          ON fu.assigned_to = u.id
          AND fu.scheduled_at BETWEEN $1 AND $2
          AND fu.is_deleted = FALSE
        WHERE u.status = 'active'
        GROUP BY u.id, u.name, u.role
        ORDER BY completed DESC`,
      [from, to]
    );

    return response.success(res, { report: rows, period: { from, to } }, 'Call performance report');
  } catch (err) {
    next(err);
  }
};

module.exports = { list, create, update, callPerformanceReport };
