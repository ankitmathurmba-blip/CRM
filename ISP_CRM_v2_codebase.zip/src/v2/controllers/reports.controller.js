/**
 * reports.controller.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Reports & Analytics Module — Controller
 *
 * Endpoints:
 *   GET /api/v2/reports/funnel
 *   GET /api/v2/reports/revenue-forecast
 *   GET /api/v2/reports/team-comparison
 *   GET /api/v2/reports/export/pdf   (Puppeteer)
 */

const { query, withTransaction } = require('../../config/database');
const response = require('../../utils/response');
const logger   = require('../../utils/logger');

// ── Lead Funnel Report ────────────────────────────────────────────────────────
const funnelReport = async (req, res, next) => {
  try {
    const { from, to, source, priority } = req.query;
    const dateFrom = from || new Date(Date.now() - 30 * 86400000).toISOString();
    const dateTo   = to   || new Date().toISOString();

    const conds  = ['l.created_at BETWEEN $1 AND $2'];
    const params = [dateFrom, dateTo];
    let   idx    = 3;

    if (source)   { conds.push(`l.lead_source = $${idx++}`); params.push(source); }
    if (priority) { conds.push(`l.priority = $${idx++}`);    params.push(priority); }

    const where = conds.join(' AND ');

    const { rows: stageCounts } = await query(
      `SELECT
          l.status,
          COUNT(*)                                               AS count,
          SUM(l.total_amount)                                   AS total_value,
          ROUND(100.0 * COUNT(*) / NULLIF(SUM(COUNT(*)) OVER (), 0), 2) AS pct_of_total
        FROM leads l
        WHERE ${where}
        GROUP BY l.status
        ORDER BY count DESC`,
      params
    );

    const { rows: conversionRate } = await query(
      `SELECT
          ROUND(
            100.0 * COUNT(*) FILTER (WHERE status = 'activated')
                  / NULLIF(COUNT(*), 0), 2
          ) AS overall_conversion_pct,
          COUNT(*) FILTER (WHERE status = 'activated') AS activated_count,
          COUNT(*)                                      AS total_count
        FROM leads l WHERE ${where}`,
      params
    );

    const { rows: sourceBreakdown } = await query(
      `SELECT lead_source, COUNT(*) AS count,
              COUNT(*) FILTER (WHERE status = 'activated') AS converted
         FROM leads l WHERE ${where}
         GROUP BY lead_source ORDER BY count DESC`,
      params
    );

    return response.success(res, {
      period:         { from: dateFrom, to: dateTo },
      funnel:         stageCounts,
      conversion:     conversionRate[0],
      by_source:      sourceBreakdown,
    }, 'Funnel report generated');
  } catch (err) { next(err); }
};

// ── Revenue Forecast ──────────────────────────────────────────────────────────
const revenueForecast = async (req, res, next) => {
  try {
    const { months = 6 } = req.query;
    const cacheKey = `revenue_forecast_${months}m`;

    // Check cache (set by 2AM cron)
    const { rows: cached } = await query(
      `SELECT payload, generated_at FROM report_cache
        WHERE report_type = 'revenue_forecast' AND period = $1
          AND expires_at > NOW()`,
      [cacheKey]
    );

    if (cached.length) {
      return response.success(res, { ...cached[0].payload, cached: true, generated_at: cached[0].generated_at }, 'Revenue forecast (cached)');
    }

    // Build live forecast
    const { rows: historical } = await query(
      `SELECT
          DATE_TRUNC('month', created_at)    AS month,
          SUM(amount_paid)                   AS revenue,
          COUNT(*)                           AS activations
        FROM leads
        WHERE status = 'activated'
          AND created_at >= NOW() - INTERVAL '6 months'
        GROUP BY 1 ORDER BY 1`
    );

    const { rows: pipeline } = await query(
      `SELECT
          l.status,
          COUNT(*)        AS count,
          SUM(l.total_amount) AS pipeline_value
        FROM leads l
        WHERE l.status NOT IN ('activated','closed','not_feasible')
        GROUP BY l.status`
    );

    // Simple linear regression for forecast
    const monthlyRevenues = historical.map((r) => parseFloat(r.revenue || 0));
    const avg = monthlyRevenues.length
      ? monthlyRevenues.reduce((a, b) => a + b, 0) / monthlyRevenues.length
      : 0;

    const projected = Array.from({ length: parseInt(months, 10) }, (_, i) => ({
      month:            new Date(Date.now() + (i + 1) * 30 * 86400000).toISOString().slice(0, 7),
      projected_revenue: Math.round(avg * (1 + i * 0.02)), // 2% growth assumption
    }));

    const payload = { historical, pipeline, projected };

    // Upsert cache for 8h
    await query(
      `INSERT INTO report_cache (report_type, period, payload, expires_at)
       VALUES ('revenue_forecast', $1, $2::jsonb, NOW() + INTERVAL '8 hours')
       ON CONFLICT (report_type, period) DO UPDATE
         SET payload = $2::jsonb, generated_at = NOW(), expires_at = NOW() + INTERVAL '8 hours'`,
      [cacheKey, JSON.stringify(payload)]
    );

    return response.success(res, { ...payload, cached: false }, 'Revenue forecast generated');
  } catch (err) { next(err); }
};

// ── Team Comparison Report ────────────────────────────────────────────────────
const teamComparison = async (req, res, next) => {
  try {
    const { from, to, role } = req.query;
    const dateFrom = from || new Date(Date.now() - 30 * 86400000).toISOString();
    const dateTo   = to   || new Date().toISOString();

    const roleCond = role ? `AND u.role = $3` : '';
    const params   = role ? [dateFrom, dateTo, role] : [dateFrom, dateTo];

    const { rows } = await query(
      `SELECT
          u.id,
          u.name,
          u.role,
          COUNT(l.id)                                            AS total_leads,
          COUNT(l.id) FILTER (WHERE l.status = 'activated')     AS activated,
          COUNT(l.id) FILTER (WHERE l.status = 'not_feasible')  AS lost,
          COALESCE(SUM(l.amount_paid), 0)                       AS revenue_generated,
          ROUND(
            100.0 * COUNT(l.id) FILTER (WHERE l.status = 'activated')
                  / NULLIF(COUNT(l.id), 0), 2
          )                                                      AS conversion_pct,
          COUNT(fu.id) FILTER (WHERE fu.status = 'completed')   AS calls_completed,
          ROUND(AVG(fu.duration_minutes) FILTER (WHERE fu.status = 'completed'), 1) AS avg_call_min
        FROM users u
        LEFT JOIN leads l
          ON (l.assigned_to = u.id OR l.created_by = u.id)
          AND l.created_at BETWEEN $1 AND $2
        LEFT JOIN follow_ups fu
          ON fu.assigned_to = u.id
          AND fu.scheduled_at BETWEEN $1 AND $2
          AND fu.is_deleted = FALSE
        WHERE u.status = 'active' ${roleCond}
        GROUP BY u.id, u.name, u.role
        ORDER BY revenue_generated DESC`,
      params
    );

    return response.success(res, { period: { from: dateFrom, to: dateTo }, team: rows }, 'Team comparison report');
  } catch (err) { next(err); }
};

// ── Export Dashboard PDF via Puppeteer ────────────────────────────────────────
const exportPDF = async (req, res, next) => {
  let browser;
  try {
    const puppeteer = require('puppeteer');
    const { type = 'funnel', from, to } = req.query;

    logger.info('[Reports] PDF export requested', { type, by: req.user.id });

    // Gather data
    const reportUrl = `${process.env.APP_URL || 'http://localhost:3000'}/reports/${type}?from=${from}&to=${to}&token=${req.headers.authorization?.split(' ')[1]}`;

    browser = await puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 900 });

    // For server-side: generate HTML report directly
    const htmlContent = await generateReportHTML(type, from, to);
    await page.setContent(htmlContent, { waitUntil: 'networkidle0' });

    const pdf = await page.pdf({
      format:           'A4',
      printBackground:  true,
      margin:           { top: '20mm', bottom: '20mm', left: '15mm', right: '15mm' },
      displayHeaderFooter: true,
      headerTemplate: `
        <div style="font-size:10px;padding:0 15mm;width:100%;text-align:right;color:#666;">
          ISP CRM — ${type.toUpperCase()} Report | ${new Date().toLocaleDateString('en-IN')}
        </div>`,
      footerTemplate: `
        <div style="font-size:9px;padding:0 15mm;width:100%;display:flex;justify-content:space-between;color:#666;">
          <span>Confidential — ReliableSoft Technologies</span>
          <span>Page <span class="pageNumber"></span> of <span class="totalPages"></span></span>
        </div>`,
    });

    res.set({
      'Content-Type':        'application/pdf',
      'Content-Disposition': `attachment; filename="crm-report-${type}-${Date.now()}.pdf"`,
      'Content-Length':      pdf.length,
    });

    logger.info('[Reports] PDF generated', { size: pdf.length, type });
    return res.send(pdf);
  } catch (err) {
    logger.error('[Reports] PDF export failed', { error: err.message });
    next(err);
  } finally {
    if (browser) await browser.close();
  }
};

// ── Generate HTML for PDF ─────────────────────────────────────────────────────
const generateReportHTML = async (type, from, to) => {
  const dateFrom = from || new Date(Date.now() - 30 * 86400000).toISOString();
  const dateTo   = to   || new Date().toISOString();

  const { rows } = await query(
    `SELECT status, COUNT(*) AS count FROM leads
      WHERE created_at BETWEEN $1 AND $2 GROUP BY status ORDER BY count DESC`,
    [dateFrom, dateTo]
  );

  const rows_html = rows.map((r) =>
    `<tr><td>${r.status}</td><td style="text-align:right">${r.count}</td></tr>`
  ).join('');

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; color: #333; }
    h1   { color: #1e3a5f; border-bottom: 2px solid #1e3a5f; padding-bottom: 8px; }
    table { border-collapse: collapse; width: 100%; margin-top: 20px; }
    th    { background: #1e3a5f; color: white; padding: 10px; text-align: left; }
    td    { padding: 8px 10px; border-bottom: 1px solid #e5e7eb; }
    tr:nth-child(even) { background: #f9fafb; }
    .meta { color: #6b7280; font-size: 13px; margin-bottom: 20px; }
  </style>
</head>
<body>
  <h1>ISP CRM — ${type.toUpperCase()} Report</h1>
  <p class="meta">Period: ${new Date(dateFrom).toLocaleDateString('en-IN')} — ${new Date(dateTo).toLocaleDateString('en-IN')}</p>
  <table>
    <thead><tr><th>Stage / Status</th><th>Count</th></tr></thead>
    <tbody>${rows_html}</tbody>
  </table>
</body>
</html>`;
};

module.exports = { funnelReport, revenueForecast, teamComparison, exportPDF };
