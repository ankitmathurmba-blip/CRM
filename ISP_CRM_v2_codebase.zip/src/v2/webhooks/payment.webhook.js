/**
 * webhooks/payment.webhook.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Payment gateway webhook receiver.
 *
 * IMPORTANT: This route must be mounted BEFORE express.json() middleware
 * so that rawBody can be captured for HMAC verification.
 *
 * Mount in server.js:
 *   app.use('/api/v2/webhooks', webhookRouter);
 */

const express  = require('express');
const router   = express.Router();
const { webhookHandler } = require('../controllers/payment.controller');
const logger   = require('../../utils/logger');

// ── Capture raw body for HMAC signature verification ──────────────────────────
router.post(
  '/payment',
  express.raw({ type: 'application/json', limit: '1mb' }),
  (req, res, next) => {
    req.rawBody = req.body; // Buffer from express.raw()
    next();
  },
  webhookHandler
);

// ── Health probe for webhook endpoint ────────────────────────────────────────
router.get('/payment', (req, res) => {
  res.json({ status: 'webhook endpoint active', method: 'POST' });
});

module.exports = router;
