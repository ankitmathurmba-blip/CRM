/**
 * authorize.middleware.js  (V2 Enhanced)
 * ─────────────────────────────────────────────────────────────────────────────
 * Extends the v1 role-based authorize() with:
 *   • Fine-grained permission checks (module + action)
 *   • Financial access flags
 *   • Module access table
 *
 * Usage:
 *   authorize('admin', 'sales')                      ← role-based (v1 compat)
 *   authorizePermission('reports', 'export')         ← permission-based
 *   requireFinancialAccess('can_view_revenue')       ← financial flag
 */

const { query }  = require('../../config/database');
const response   = require('../../utils/response');
const logger     = require('../../utils/logger');

// ── V1-Compatible role guard ──────────────────────────────────────────────────
const authorize = (...allowedRoles) => (req, res, next) => {
  if (!req.user) return response.unauthorized(res);
  if (req.user.role === 'admin') return next();
  if (!allowedRoles.includes(req.user.role)) {
    logger.warn('[AuthorizeV2] Forbidden', {
      userId: req.user.id, role: req.user.role, allowedRoles, path: req.path,
    });
    return response.forbidden(res);
  }
  next();
};

// ── Fine-grained permission check ─────────────────────────────────────────────
/**
 * Checks `role_permissions` and `permissions` tables.
 * Admin bypasses all permission checks.
 */
const authorizePermission = (module, action) => async (req, res, next) => {
  try {
    if (!req.user) return response.unauthorized(res);
    if (req.user.role === 'admin') return next();

    const { rows } = await query(
      `SELECT rp.granted
         FROM role_permissions rp
         JOIN permissions p ON rp.permission_id = p.id
        WHERE rp.role = $1 AND p.module = $2 AND p.action = $3
        LIMIT 1`,
      [req.user.role, module, action]
    );

    if (rows.length && rows[0].granted) {
      return next();
    }

    logger.warn('[AuthorizeV2] Permission denied', {
      userId: req.user.id, role: req.user.role, module, action,
    });
    return response.forbidden(res, `Permission denied: ${module}:${action}`);
  } catch (err) {
    logger.error('[AuthorizeV2] Permission check error', { error: err.message });
    return response.error(res, 'Authorization check failed');
  }
};

// ── Module access check ───────────────────────────────────────────────────────
const requireModuleAccess = (moduleName) => async (req, res, next) => {
  try {
    if (!req.user) return response.unauthorized(res);
    if (req.user.role === 'admin') return next();

    const { rows } = await query(
      'SELECT can_access FROM module_access WHERE role = $1 AND module = $2',
      [req.user.role, moduleName]
    );

    if (rows.length && rows[0].can_access) return next();

    return response.forbidden(res, `Module access denied: ${moduleName}`);
  } catch (err) {
    logger.error('[AuthorizeV2] Module access check error', { error: err.message });
    return response.error(res, 'Module access check failed');
  }
};

// ── Financial access flag check ───────────────────────────────────────────────
/**
 * @param {'can_view_revenue'|'can_view_commissions'|'can_export_payments'|'can_approve_refunds'} flag
 */
const requireFinancialAccess = (flag) => async (req, res, next) => {
  try {
    if (!req.user) return response.unauthorized(res);
    if (req.user.role === 'admin') return next();

    const { rows } = await query(
      `SELECT ${flag} AS granted FROM financial_access_flags WHERE user_id = $1`,
      [req.user.id]
    );

    if (rows.length && rows[0].granted) return next();

    logger.warn('[AuthorizeV2] Financial access denied', {
      userId: req.user.id, flag,
    });
    return response.forbidden(res, `Financial access denied: ${flag}`);
  } catch (err) {
    logger.error('[AuthorizeV2] Financial access check error', { error: err.message });
    return response.error(res, 'Financial access check failed');
  }
};

module.exports = {
  authorize,
  authorizePermission,
  requireModuleAccess,
  requireFinancialAccess,
};
