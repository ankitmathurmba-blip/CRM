/**
 * featureFlag.middleware.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Module-based enable/disable guard for all /api/v2 routes.
 *
 * Usage in routes:
 *   router.use(requireFeature('MODULE_FOLLOWUPS'));
 *   router.get('/', requireFeature('MODULE_REPORTS'), controller.list);
 *
 * Flags are cached for CACHE_TTL_MS to avoid DB hit on every request.
 * Cache is invalidated on POST /api/v2/admin/feature-flags.
 */

const { query } = require('../../config/database');
const response   = require('../../utils/response');
const logger     = require('../../utils/logger');

// ── In-memory cache ───────────────────────────────────────────────────────────
const CACHE_TTL_MS = 60_000; // 60 seconds
let   flagCache    = new Map();
let   cacheSetAt   = 0;

const isCacheValid = () => Date.now() - cacheSetAt < CACHE_TTL_MS;

/**
 * Load all flags from DB into cache.
 * Returns Map<flagKey, isEnabled>
 */
const loadFlags = async () => {
  const { rows } = await query(
    'SELECT flag_key, is_enabled, enabled_for FROM feature_flags'
  );
  const map = new Map();
  rows.forEach((r) => map.set(r.flag_key, { is_enabled: r.is_enabled, enabled_for: r.enabled_for }));
  flagCache = map;
  cacheSetAt = Date.now();
  return map;
};

/** Force-invalidate cache (call after flag update). */
const invalidateFlagCache = () => {
  cacheSetAt = 0;
  flagCache  = new Map();
  logger.debug('[FeatureFlag] Cache invalidated');
};

/**
 * Check if a flag is enabled for the current request user.
 * `enabled_for` supports:
 *   - []                      → use global is_enabled
 *   - ["role:admin"]          → enabled for admin role
 *   - ["user:uuid"]           → enabled for specific user
 */
const isFlagEnabled = (flagData, user) => {
  if (!flagData) return false;

  const { is_enabled, enabled_for } = flagData;

  // Granular overrides
  if (Array.isArray(enabled_for) && enabled_for.length > 0 && user) {
    if (enabled_for.includes(`role:${user.role}`)) return true;
    if (enabled_for.includes(`user:${user.id}`))   return true;
  }

  return is_enabled;
};

/**
 * Middleware factory — guards a route behind a feature flag.
 *
 * @param {string} flagKey  — e.g. 'MODULE_FOLLOWUPS'
 */
const requireFeature = (flagKey) => async (req, res, next) => {
  try {
    const flags = isCacheValid() ? flagCache : await loadFlags();
    const flag  = flags.get(flagKey);

    if (isFlagEnabled(flag, req.user)) {
      return next();
    }

    logger.warn('[FeatureFlag] Module disabled', {
      flagKey,
      userId: req.user?.id,
      path:   req.path,
    });

    return response.error(res, `Module '${flagKey}' is currently disabled`, 503);
  } catch (err) {
    logger.error('[FeatureFlag] Error checking flag', { flagKey, error: err.message });
    // Fail-open in dev, fail-closed in production
    if (process.env.NODE_ENV === 'production') {
      return response.error(res, 'Feature check failed', 503);
    }
    next(); // fail-open in development
  }
};

module.exports = { requireFeature, invalidateFlagCache, loadFlags };
