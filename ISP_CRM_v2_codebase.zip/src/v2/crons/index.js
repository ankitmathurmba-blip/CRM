/**
 * crons/index.js
 * ─────────────────────────────────────────────────────────────────────────────
 * ISP CRM V2 — Cron Job Registry
 *
 * Jobs:
 *   • Every 5 min  — 5-minute follow-up reminders
 *   • Every 5 min  — Mark 30-minute overdue follow-ups
 *   • Daily 02:00  — Revenue forecast cache pre-computation
 *   • Daily 09:00 IST — Payment reminder notifications
 *
 * Usage: require('./crons').startAll();
 */

const cron   = require('node-cron');
const { query, withTransaction } = require('../../config/database');
const logger = require('../../utils/logger');

// ── Utility: create notification for a user ────────────────────────────────────
const createNotification = async (client, { userId, title, message, meta = {} }) => {
  try {
    await client.query(
      `INSERT INTO notifications (user_id, title, message, meta)
       VALUES ($1,$2,$3,$4::jsonb)`,
      [userId, title, message, JSON.stringify(meta)]
    );
  } catch (err) {
    logger.warn('[Cron] Failed to create notification', { error: err.message });
  }
};

// ── JOB 1: 5-Minute Follow-Up Reminder ────────────────────────────────────────
const followup5MinReminder = async () => {
  logger.debug('[Cron] Running 5-min follow-up reminder check');
  try {
    // Find follow-ups due in next 5 min where reminder not yet sent
    const { rows } = await query(
      `SELECT fu.id, fu.assigned_to, fu.lead_id, fu.followup_type, fu.scheduled_at,
              l.customer_name, u.name AS assigned_name
         FROM follow_ups fu
         JOIN leads l ON fu.lead_id = l.id
         JOIN users u ON fu.assigned_to = u.id
        WHERE fu.status = 'pending'
          AND fu.is_deleted = FALSE
          AND fu.reminder_5min_sent = FALSE
          AND fu.scheduled_at BETWEEN NOW() AND NOW() + INTERVAL '5 minutes'`
    );

    if (!rows.length) return;

    logger.info('[Cron] 5-min reminders to send', { count: rows.length });

    for (const fu of rows) {
      await withTransaction(async (client) => {
        await createNotification(client, {
          userId:  fu.assigned_to,
          title:   '⏰ Follow-up in 5 minutes',
          message: `${fu.followup_type.toUpperCase()} with ${fu.customer_name} at ${new Date(fu.scheduled_at).toLocaleTimeString('en-IN')}`,
          meta:    { followup_id: fu.id, lead_id: fu.lead_id, type: 'followup_reminder' },
        });

        await client.query(
          'UPDATE follow_ups SET reminder_5min_sent = TRUE WHERE id = $1',
          [fu.id]
        );
      });
    }

    logger.info('[Cron] 5-min reminders sent', { count: rows.length });
  } catch (err) {
    logger.error('[Cron] 5-min reminder error', { error: err.message });
  }
};

// ── JOB 2: 30-Minute Overdue Marker ───────────────────────────────────────────
const followupOverdueMarker = async () => {
  logger.debug('[Cron] Running overdue follow-up check');
  try {
    const { rows } = await query(
      `UPDATE follow_ups
         SET status = 'overdue', updated_at = NOW()
       WHERE status = 'pending'
         AND is_deleted = FALSE
         AND scheduled_at < NOW() - INTERVAL '30 minutes'
       RETURNING id, assigned_to, lead_id`
    );

    if (!rows.length) return;

    logger.warn('[Cron] Follow-ups marked overdue', { count: rows.length });

    // Notify each assigned user
    for (const fu of rows) {
      const { rows: userRows } = await query(
        'SELECT id FROM users WHERE id = $1 AND status = \'active\'',
        [fu.assigned_to]
      );
      if (!userRows.length) continue;

      await query(
        `INSERT INTO notifications (user_id, title, message, meta)
         VALUES ($1,'🔴 Follow-up Overdue','A scheduled follow-up was not completed on time.',$2::jsonb)`,
        [fu.assigned_to, JSON.stringify({ followup_id: fu.id, lead_id: fu.lead_id, type: 'overdue_alert' })]
      );
    }
  } catch (err) {
    logger.error('[Cron] Overdue marker error', { error: err.message });
  }
};

// ── JOB 3: Revenue Forecast Cache (02:00 daily) ───────────────────────────────
const revenueForecastCacheJob = async () => {
  logger.info('[Cron] Building revenue forecast cache...');
  try {
    const { rows: historical } = await query(
      `SELECT DATE_TRUNC('month', created_at) AS month,
              SUM(amount_paid) AS revenue,
              COUNT(*)         AS activations
         FROM leads
        WHERE status = 'activated' AND created_at >= NOW() - INTERVAL '6 months'
        GROUP BY 1 ORDER BY 1`
    );

    const { rows: pipeline } = await query(
      `SELECT status, COUNT(*) AS count, SUM(total_amount) AS pipeline_value
         FROM leads
        WHERE status NOT IN ('activated','closed','not_feasible')
        GROUP BY status`
    );

    const monthlyRevs = historical.map((r) => parseFloat(r.revenue || 0));
    const avg = monthlyRevs.length
      ? monthlyRevs.reduce((a, b) => a + b, 0) / monthlyRevs.length
      : 0;

    const projected = Array.from({ length: 6 }, (_, i) => ({
      month:            new Date(Date.now() + (i + 1) * 30 * 86400000).toISOString().slice(0, 7),
      projected_revenue: Math.round(avg * (1 + i * 0.02)),
    }));

    const payload = { historical, pipeline, projected };

    await query(
      `INSERT INTO report_cache (report_type, period, payload, expires_at)
       VALUES ('revenue_forecast','revenue_forecast_6m',$1::jsonb, NOW() + INTERVAL '26 hours')
       ON CONFLICT (report_type, period) DO UPDATE
         SET payload = $1::jsonb, generated_at = NOW(), expires_at = NOW() + INTERVAL '26 hours'`,
      [JSON.stringify(payload)]
    );

    logger.info('[Cron] Revenue forecast cache updated', {
      historical_months: historical.length,
      avg_monthly: Math.round(avg),
    });
  } catch (err) {
    logger.error('[Cron] Revenue forecast cache error', { error: err.message });
  }
};

// ── JOB 4: Payment Reminder (09:00 IST = 03:30 UTC) ──────────────────────────
const paymentReminderJob = async () => {
  logger.info('[Cron] Running payment reminder job...');
  try {
    // Leads with pending/partial payment older than 3 days
    const { rows } = await query(
      `SELECT l.id AS lead_id, l.customer_name, l.mobile,
              l.total_amount, l.amount_paid,
              (l.total_amount - l.amount_paid) AS balance,
              u.id AS assigned_to, u.name AS assigned_name
         FROM leads l
         JOIN users u ON l.assigned_to = u.id
        WHERE l.payment_status IN ('pending','partial')
          AND l.status NOT IN ('not_feasible','closed')
          AND l.updated_at < NOW() - INTERVAL '3 days'
          AND u.status = 'active'
        ORDER BY balance DESC
        LIMIT 100`
    );

    if (!rows.length) {
      logger.info('[Cron] No payment reminders needed');
      return;
    }

    logger.info('[Cron] Sending payment reminders', { count: rows.length });

    for (const lead of rows) {
      await query(
        `INSERT INTO notifications (user_id, title, message, meta)
         VALUES ($1,'💰 Payment Pending',$2,$3::jsonb)`,
        [
          lead.assigned_to,
          `${lead.customer_name} — Balance ₹${parseFloat(lead.balance).toLocaleString('en-IN')} pending`,
          JSON.stringify({ lead_id: lead.lead_id, balance: lead.balance, type: 'payment_reminder' }),
        ]
      );
    }

    logger.info('[Cron] Payment reminders sent', { count: rows.length });
  } catch (err) {
    logger.error('[Cron] Payment reminder error', { error: err.message });
  }
};

// ═════════════════════════════════════════════════════════════════════════════
// SCHEDULER REGISTRATION
// ═════════════════════════════════════════════════════════════════════════════

const startAll = () => {
  logger.info('[Cron] Starting V2 cron jobs...');

  // Every 5 minutes — follow-up reminders
  cron.schedule('*/5 * * * *', followup5MinReminder, {
    name:     'followup-5min-reminder',
    timezone: 'Asia/Kolkata',
  });

  // Every 5 minutes — overdue follow-up check
  cron.schedule('*/5 * * * *', followupOverdueMarker, {
    name:     'followup-overdue-marker',
    timezone: 'Asia/Kolkata',
  });

  // Daily at 02:00 IST — revenue forecast cache
  cron.schedule('0 2 * * *', revenueForecastCacheJob, {
    name:     'revenue-forecast-cache',
    timezone: 'Asia/Kolkata',
  });

  // Daily at 09:00 IST — payment reminders
  cron.schedule('0 9 * * *', paymentReminderJob, {
    name:     'payment-reminder',
    timezone: 'Asia/Kolkata',
  });

  logger.info('[Cron] ✅ All V2 cron jobs scheduled');
};

module.exports = {
  startAll,
  // Expose individual jobs for testing
  followup5MinReminder,
  followupOverdueMarker,
  revenueForecastCacheJob,
  paymentReminderJob,
};
