/**
 * v2/routes/index.js
 * ─────────────────────────────────────────────────────────────────────────────
 * ISP CRM V2 — Master Router
 * Mounts all v2 sub-routers under /api/v2
 *
 * CRITICAL: Does NOT modify any /api/v1 routes.
 */

const express = require('express');
const router  = express.Router();

const { authenticate }   = require('../../middleware/auth.middleware');
const { requireFeature } = require('../middleware/featureFlag.middleware');
const {
  authorize,
  authorizePermission,
  requireModuleAccess,
  requireFinancialAccess,
} = require('../middleware/authorize.middleware');

const followupCtrl    = require('../controllers/followup.controller');
const timelineCtrl    = require('../controllers/timeline.controller');
const settingsCtrl    = require('../controllers/settings.controller');
const permissionsCtrl = require('../controllers/permissions.controller');
const reportsCtrl     = require('../controllers/reports.controller');
const paymentCtrl     = require('../controllers/payment.controller');

const { body, param, query: qv } = require('express-validator');
const { validateRequest } = require('../../middleware/validate.middleware');

// ── All v2 routes require authentication ──────────────────────────────────────
router.use(authenticate);

// ═════════════════════════════════════════════════════════════════════════════
// MODULE 1 — CALL & FOLLOW-UP  /api/v2/leads/:id/followups
// ═════════════════════════════════════════════════════════════════════════════
router.get(
  '/leads/:id/followups',
  requireFeature('MODULE_FOLLOWUPS'),
  authorize('admin', 'sales', 'it', 'installation', 'accounts'),
  followupCtrl.list
);

router.post(
  '/leads/:id/followups',
  requireFeature('MODULE_FOLLOWUPS'),
  authorize('admin', 'sales'),
  [
    body('followup_type').isIn(['call','whatsapp','email','visit','sms']),
    body('scheduled_at').isISO8601().withMessage('Provide a valid ISO 8601 date'),
  ],
  validateRequest,
  followupCtrl.create
);

router.patch(
  '/leads/:id/followups/:fuId',
  requireFeature('MODULE_FOLLOWUPS'),
  authorize('admin', 'sales'),
  followupCtrl.update
);

// Call performance report
router.get(
  '/reports/call-performance',
  requireFeature('MODULE_FOLLOWUPS'),
  authorize('admin', 'sales'),
  followupCtrl.callPerformanceReport
);

// ═════════════════════════════════════════════════════════════════════════════
// MODULE 2 — LEAD TIMELINE  /api/v2/leads/:id/timeline
// ═════════════════════════════════════════════════════════════════════════════
router.get(
  '/leads/:id/timeline',
  requireFeature('MODULE_TIMELINE'),
  authorize('admin', 'sales', 'it', 'installation', 'accounts'),
  timelineCtrl.getTimeline
);

router.post(
  '/leads/:id/timeline',
  requireFeature('MODULE_TIMELINE'),
  authorize('admin', 'sales'),
  [body('description').notEmpty().withMessage('Description is required')],
  validateRequest,
  timelineCtrl.addNote
);

// Attachment upload (multer configured in server setup)
router.post(
  '/leads/:id/timeline/attachments',
  requireFeature('MODULE_TIMELINE'),
  authorize('admin', 'sales', 'it', 'installation', 'accounts'),
  timelineCtrl.addAttachment
);

// ═════════════════════════════════════════════════════════════════════════════
// MODULE 3 — MASTER SETTINGS  /api/v2/settings
// ═════════════════════════════════════════════════════════════════════════════
const settingsRouter = express.Router();
settingsRouter.use(requireFeature('MODULE_SETTINGS'), authorize('admin'));

// Custom fields
settingsRouter.get('/custom-fields',              settingsCtrl.listCustomFields);
settingsRouter.post('/custom-fields',             settingsCtrl.createCustomField);
settingsRouter.patch('/custom-fields/:fieldId',   settingsCtrl.updateCustomField);

// Lead custom field values
settingsRouter.get('/leads/:leadId/custom-values',   settingsCtrl.getLeadCustomValues);
settingsRouter.post('/leads/:leadId/custom-values',  settingsCtrl.upsertLeadCustomValue);

// Pipeline stages
settingsRouter.get('/pipeline-stages',            settingsCtrl.listStages);
settingsRouter.post('/pipeline-stages',           settingsCtrl.createStage);

// Scoring rules
settingsRouter.get('/scoring-rules',              settingsCtrl.listScoringRules);
settingsRouter.post('/scoring-rules',             settingsCtrl.createScoringRule);

// Assignment rules
settingsRouter.get('/assignment-rules',           settingsCtrl.listAssignmentRules);
settingsRouter.post('/assignment-rules',          settingsCtrl.createAssignmentRule);

// Feature flags
settingsRouter.get('/feature-flags',              settingsCtrl.listFeatureFlags);
settingsRouter.patch('/feature-flags/:flagKey',   settingsCtrl.updateFeatureFlag);

router.use('/settings', settingsRouter);

// ═════════════════════════════════════════════════════════════════════════════
// MODULE 4 — ROLE PERMISSIONS  /api/v2/permissions
// ═════════════════════════════════════════════════════════════════════════════
const permRouter = express.Router();
permRouter.use(requireFeature('MODULE_PERMISSIONS'), authorize('admin'));

permRouter.get('/',                           permissionsCtrl.listPermissions);
permRouter.get('/roles/:role',                permissionsCtrl.getRolePermissions);
permRouter.post('/roles/:role',               permissionsCtrl.setRolePermission);
permRouter.get('/module-access',              permissionsCtrl.getModuleAccess);
permRouter.post('/module-access',             permissionsCtrl.setModuleAccess);
permRouter.get('/financial-flags/:userId',    permissionsCtrl.getFinancialFlags);
permRouter.put('/financial-flags/:userId',    permissionsCtrl.setFinancialFlags);

router.use('/permissions', permRouter);

// ═════════════════════════════════════════════════════════════════════════════
// MODULE 5 — REPORTS & ANALYTICS  /api/v2/reports
// ═════════════════════════════════════════════════════════════════════════════
const reportsRouter = express.Router();
reportsRouter.use(requireFeature('MODULE_REPORTS'), authorizePermission('reports', 'read'));

reportsRouter.get('/funnel',           reportsCtrl.funnelReport);
reportsRouter.get('/revenue-forecast', reportsCtrl.revenueForecast);
reportsRouter.get('/team-comparison',  reportsCtrl.teamComparison);
reportsRouter.get('/export/pdf',       authorizePermission('reports', 'export'), reportsCtrl.exportPDF);

router.use('/reports', reportsRouter);

// ═════════════════════════════════════════════════════════════════════════════
// MODULE 6 — PAYMENTS V2  /api/v2/payments
// ═════════════════════════════════════════════════════════════════════════════
const payRouter = express.Router();
payRouter.use(requireFeature('MODULE_PAYMENTS_V2'));

payRouter.get('/',
  authorizePermission('payments', 'read'),
  paymentCtrl.listPayments
);

payRouter.post('/',
  authorize('admin', 'accounts'),
  [
    body('lead_id').isUUID(),
    body('amount').isNumeric().isFloat({ min: 1 }),
    body('payment_mode').notEmpty(),
  ],
  validateRequest,
  paymentCtrl.createPayment
);

// Commission rules
payRouter.get('/commission-rules',  authorize('admin'), paymentCtrl.listCommissionRules);
payRouter.post('/commission-rules', authorize('admin'), paymentCtrl.createCommissionRule);

// Commissions
payRouter.get('/commissions',
  requireFinancialAccess('can_view_commissions'),
  paymentCtrl.listCommissions
);

router.use('/payments', payRouter);

// ═════════════════════════════════════════════════════════════════════════════
// V2 HEALTH CHECK
// ═════════════════════════════════════════════════════════════════════════════
router.get('/health', (req, res) => {
  res.json({
    status:  'ok',
    version: 'v2',
    modules: ['followups','timeline','settings','permissions','reports','payments'],
    ts:      new Date().toISOString(),
  });
});

module.exports = router;
