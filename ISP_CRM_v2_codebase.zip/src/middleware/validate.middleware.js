/**
 * validate.middleware.js
 * Centralised express-validator result handler used by v1 & v2.
 */

const { validationResult } = require('express-validator');
const response = require('../utils/response');

const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return response.badRequest(res, 'Validation failed', errors.array());
  }
  next();
};

module.exports = { validateRequest };
