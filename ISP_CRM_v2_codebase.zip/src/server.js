/**
 * server.js  (V2 UPGRADED)
 * ─────────────────────────────────────────────────────────────────────────────
 * ISP CRM — Express Application Entry Point
 *
 * V2 additions (zero changes to existing /api/v1 logic):
 *  • /api/v2 routes mounted alongside /api/v1
 *  • /api/v2/webhooks mounted BEFORE json() parsing (raw body required)
 *  • node-cron V2 jobs started on server start
 *  • Multer configured for attachment uploads
 *
 * BACKWARD COMPATIBILITY:
 *  ✅ All /api/v1 routes completely unchanged
 *  ✅ All existing middleware unchanged
 *  ✅ Same DB pool instance shared
 */

require('dotenv').config();

const express       = require('express');
const helmet        = require('helmet');
const cors          = require('cors');
const compression   = require('compression');
const morgan        = require('morgan');
const rateLimit     = require('express-rate-limit');
const multer        = require('multer');
const path          = require('path');
const fs            = require('fs');

const logger                            = require('./utils/logger');
const { checkConnection }               = require('./config/database');
const v1Routes                          = require('./routes/index.routes');       // ← UNCHANGED v1
const v2Routes                          = require('./v2/routes/index');            // ← NEW v2
const webhookRouter                     = require('./v2/webhooks/payment.webhook'); // ← NEW webhooks
const { errorHandler, notFoundHandler } = require('./middleware/error.middleware');
const crons                             = require('./v2/crons/index');

// ── App init ──────────────────────────────────────────────────────────────────
const app   = express();
const PORT  = process.env.PORT || 5000;
const API_V1 = process.env.API_PREFIX || '/api/v1';
const API_V2 = '/api/v2';

// ── Security middleware ───────────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy:        false,
  crossOriginResourcePolicy:    { policy: 'cross-origin' },
}));

app.use(cors({
  origin:      process.env.CORS_ORIGIN || 'http://localhost:3000',
  credentials: true,
  methods:     ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization','X-Request-ID','X-Webhook-Signature'],
}));

// ── Rate limiting ─────────────────────────────────────────────────────────────
const globalLimiter = rateLimit({
  windowMs:        parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000', 10),
  max:             parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100', 10),
  standardHeaders: true,
  legacyHeaders:   false,
  message:         { success: false, message: 'Too many requests' },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max:      20,
  message:  { success: false, message: 'Too many login attempts' },
});

// Webhook gets its own higher-limit rate limiter
const webhookLimiter = rateLimit({
  windowMs: 60 * 1000,
  max:      300,
  message:  { success: false, message: 'Webhook rate limit exceeded' },
});

app.use(`${API_V1}/auth/login`, authLimiter);
app.use(API_V1, globalLimiter);
app.use(API_V2, globalLimiter);

// ── WEBHOOKS — must be mounted BEFORE express.json() ─────────────────────────
// express.raw() is applied per-route inside webhookRouter
app.use(`${API_V2}/webhooks`, webhookLimiter, webhookRouter);

// ── Request parsing ───────────────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(compression());

// ── HTTP logging ──────────────────────────────────────────────────────────────
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('combined', {
    stream: { write: (msg) => logger.http(msg.trim()) },
    skip:   (req) => req.path.includes('/health'),
  }));
}

// ── Multer — file uploads for timeline attachments ────────────────────────────
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, '../uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename:    (req, file, cb) => {
    const ext  = path.extname(file.originalname);
    const name = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
    cb(null, name);
  },
});

const upload = multer({
  storage,
  limits:    { fileSize: parseInt(process.env.MAX_FILE_SIZE_MB || '10', 10) * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = (process.env.ALLOWED_FILE_TYPES || 'jpg,jpeg,png,pdf,doc,docx').split(',');
    const ext = path.extname(file.originalname).slice(1).toLowerCase();
    allowed.includes(ext) ? cb(null, true) : cb(new Error(`File type .${ext} not allowed`));
  },
});

// Attach multer to timeline attachment endpoint
app.use(`${API_V2}/leads`, (req, res, next) => {
  if (req.path.includes('/attachments') && req.method === 'POST') {
    return upload.single('file')(req, res, next);
  }
  next();
});

// ── Static uploads ────────────────────────────────────────────────────────────
app.use('/uploads', express.static(UPLOAD_DIR));

// ── API Routes ────────────────────────────────────────────────────────────────
app.use(API_V1, v1Routes);   // ← UNCHANGED v1 routes
app.use(API_V2, v2Routes);   // ← NEW v2 routes

// ── Root ──────────────────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    app:         'ISP CRM API',
    company:     process.env.COMPANY_NAME || 'ReliableSoft Technologies',
    versions:    ['v1', 'v2'],
    environment: process.env.NODE_ENV,
  });
});

// ── 404 & Error ───────────────────────────────────────────────────────────────
app.use(notFoundHandler);
app.use(errorHandler);

// ── Graceful shutdown ─────────────────────────────────────────────────────────
const gracefulShutdown = (signal) => {
  logger.info(`[Server] ${signal} received — shutting down...`);
  server.close(() => {
    require('./config/database').pool.end(() => {
      logger.info('[DB] Pool closed');
      process.exit(0);
    });
  });
  setTimeout(() => process.exit(1), 10000);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT',  () => gracefulShutdown('SIGINT'));
process.on('uncaughtException',  (err) => logger.error('[Server] Uncaught', { error: err.message }));
process.on('unhandledRejection', (err) => logger.error('[Server] Unhandled rejection', { error: err?.message }));

// ── Start ─────────────────────────────────────────────────────────────────────
let server;

const start = async () => {
  logger.info('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  logger.info(`  ISP CRM API — ${process.env.COMPANY_NAME}`);
  logger.info('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  const dbOk = await checkConnection();
  if (!dbOk) {
    logger.error('[Server] Cannot connect to PostgreSQL — aborting');
    process.exit(1);
  }

  // Start V2 cron jobs
  if (process.env.NODE_ENV !== 'test') {
    crons.startAll();
  }

  server = app.listen(PORT, () => {
    logger.info(`[Server] http://localhost:${PORT}`);
    logger.info(`[Server] V1 API: ${API_V1}`);
    logger.info(`[Server] V2 API: ${API_V2}`);
    logger.info(`[Server] Webhooks: ${API_V2}/webhooks`);
  });
};

start();

module.exports = app;
