/**
 * rollback_v2.js
 * ─────────────────────────────────────────────────────────────────────────────
 * ISP CRM — V2 Complete Rollback Script
 *
 * SAFETY GUARANTEES:
 *  ✅ Drops ONLY v2 tables/triggers/functions (never touches v1 schema)
 *  ✅ Preserves all existing leads, users, audit_logs tables
 *  ✅ Idempotent — safe to run multiple times
 *  ✅ Cascading order respects FK dependencies
 *
 * Run: node migrations/rollback_v2.js
 * Dry run: DRY_RUN=true node migrations/rollback_v2.js
 */

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const { Pool } = require('pg');
const logger   = require('../src/utils/logger');

const DRY_RUN = process.env.DRY_RUN === 'true';

const pool = new Pool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT || '5432', 10),
  database: process.env.DB_NAME     || 'isp_crm',
  user:     process.env.DB_USER     || 'postgres',
  password: process.env.DB_PASSWORD || '',
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

// ── Rollback steps in reverse dependency order ──────────────────────────────
const rollbackSteps = [

  // 1. Trigger on leads table (must drop before dropping fn)
  `DROP TRIGGER  IF EXISTS trg_lead_activity     ON leads;`,
  `DROP FUNCTION IF EXISTS fn_log_lead_activity();`,

  // 2. Commission data (child before parent)
  `DROP TABLE IF EXISTS commissions              CASCADE;`,
  `DROP TABLE IF EXISTS commission_rules         CASCADE;`,
  `DROP TABLE IF EXISTS payment_transactions     CASCADE;`,

  // 3. Reports cache
  `DROP TABLE IF EXISTS report_cache             CASCADE;`,

  // 4. Permissions
  `DROP TABLE IF EXISTS financial_access_flags   CASCADE;`,
  `DROP TABLE IF EXISTS module_access            CASCADE;`,
  `DROP TABLE IF EXISTS role_permissions         CASCADE;`,
  `DROP TABLE IF EXISTS permissions              CASCADE;`,

  // 5. Master Settings
  `DROP TABLE IF EXISTS assignment_rules         CASCADE;`,
  `DROP TABLE IF EXISTS lead_scoring_rules       CASCADE;`,
  `DROP TABLE IF EXISTS pipeline_stages          CASCADE;`,
  `DROP TABLE IF EXISTS lead_custom_field_values CASCADE;`,
  `DROP TABLE IF EXISTS custom_field_definitions CASCADE;`,

  // 6. Activity attachments (child of lead_activities)
  `DROP TABLE IF EXISTS activity_attachments     CASCADE;`,
  `DROP TABLE IF EXISTS lead_activities          CASCADE;`,

  // 7. Follow-ups
  `DROP TABLE IF EXISTS follow_ups               CASCADE;`,

  // 8. Feature flags
  `DROP TABLE IF EXISTS feature_flags            CASCADE;`,

  // 9. V2 ENUM types
  `DROP TYPE IF EXISTS followup_type             CASCADE;`,
  `DROP TYPE IF EXISTS followup_status           CASCADE;`,
  `DROP TYPE IF EXISTS activity_type             CASCADE;`,
  `DROP TYPE IF EXISTS commission_type           CASCADE;`,
  `DROP TYPE IF EXISTS commission_status         CASCADE;`,
  `DROP TYPE IF EXISTS txn_status                CASCADE;`,
  `DROP TYPE IF EXISTS field_type                CASCADE;`,

  // 10. Migration tracking table
  `DROP TABLE IF EXISTS schema_migrations_v2     CASCADE;`,
];

// ── V1 tables that must NEVER be touched (safety check) ─────────────────────
const PROTECTED_TABLES = new Set([
  'users', 'leads', 'packages', 'areas', 'audit_logs',
  'notifications', 'lead_documents', 'lead_comments',
  'schema_migrations',
]);

const runRollback = async () => {
  if (DRY_RUN) {
    logger.warn('[RollbackV2] 🔶 DRY RUN mode — no changes will be made');
    rollbackSteps.forEach((step) => logger.info(`[DRY RUN] Would execute: ${step}`));
    logger.info('[RollbackV2] Dry run complete');
    return;
  }

  // Confirmation for non-CI environments
  if (process.env.NODE_ENV === 'production' && !process.env.CONFIRM_ROLLBACK) {
    logger.error('[RollbackV2] ❌ Set CONFIRM_ROLLBACK=true to rollback in production');
    process.exit(1);
  }

  const client = await pool.connect();
  try {
    logger.warn('[RollbackV2] 🚨 Starting V2 rollback — this will remove all v2 data');
    logger.info(`[RollbackV2] Executing ${rollbackSteps.length} rollback step(s)...`);

    await client.query('BEGIN');

    for (const step of rollbackSteps) {
      // Extra safety guard
      const hasForbidden = [...PROTECTED_TABLES].some((t) =>
        step.toLowerCase().includes(t.toLowerCase()) && !step.toLowerCase().includes('if exists')
      );
      if (hasForbidden) {
        await client.query('ROLLBACK');
        logger.error(`[RollbackV2] ⛔ BLOCKED — step targets protected table: ${step}`);
        process.exit(1);
      }

      try {
        await client.query(step);
        logger.info(`[RollbackV2] ✓ ${step.trim()}`);
      } catch (err) {
        await client.query('ROLLBACK');
        logger.error('[RollbackV2] Step failed', { step, error: err.message });
        throw err;
      }
    }

    await client.query('COMMIT');
    logger.info('[RollbackV2] ✅ V2 rollback completed — v1 schema fully intact');
  } catch (err) {
    logger.error('[RollbackV2] Fatal error — transaction rolled back', { error: err.message });
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
};

runRollback();
