/**
 * migrate_v2.js
 * ─────────────────────────────────────────────────────────────────────────────
 * ISP CRM — V2 Additive Migrations
 *
 * CRITICAL RULES:
 *  • Zero breaking changes — all existing /api/v1 endpoints remain untouched
 *  • Zero column drops or modifications on existing tables
 *  • All new tables use IF NOT EXISTS for idempotency
 *  • All FKs reference existing leads/users tables
 *
 * Run: node migrations/migrate_v2.js
 */

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const { Pool } = require('pg');
const logger   = require('../src/utils/logger');

const pool = new Pool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT || '5432', 10),
  database: process.env.DB_NAME     || 'isp_crm',
  user:     process.env.DB_USER     || 'postgres',
  password: process.env.DB_PASSWORD || '',
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

// ═════════════════════════════════════════════════════════════════════════════
// MIGRATION STEPS  (idempotent — safe to re-run)
// ═════════════════════════════════════════════════════════════════════════════

const migrations = [

  // ── V2-001  Feature Flags ────────────────────────────────────────────────
  {
    name: 'v2_001_feature_flags',
    sql: `
      CREATE TABLE IF NOT EXISTS feature_flags (
        id          UUID          PRIMARY KEY DEFAULT uuid_generate_v4(),
        flag_key    VARCHAR(100)  NOT NULL UNIQUE,
        description TEXT,
        is_enabled  BOOLEAN       NOT NULL DEFAULT FALSE,
        enabled_for JSONB         DEFAULT '[]'::JSONB,  -- ["role:admin","user:uuid"]
        created_at  TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
        updated_at  TIMESTAMPTZ   NOT NULL DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_feature_flags_key ON feature_flags(flag_key);

      -- Seed default flags
      INSERT INTO feature_flags (flag_key, description, is_enabled) VALUES
        ('MODULE_FOLLOWUPS',     'Call & Follow-Up Module',       TRUE),
        ('MODULE_TIMELINE',      'Lead Timeline Module',           TRUE),
        ('MODULE_SETTINGS',      'Master Settings Module',         TRUE),
        ('MODULE_PERMISSIONS',   'Role Permissions Module',        TRUE),
        ('MODULE_REPORTS',       'Reports & Analytics Module',     TRUE),
        ('MODULE_PAYMENTS_V2',   'Payment Enhancement Module',     TRUE)
      ON CONFLICT (flag_key) DO NOTHING;
    `,
  },

  // ── V2-002  New ENUM types ────────────────────────────────────────────────
  {
    name: 'v2_002_enums',
    sql: `
      DO $$ BEGIN
        CREATE TYPE followup_type AS ENUM (
          'call','whatsapp','email','visit','sms'
        );
      EXCEPTION WHEN duplicate_object THEN NULL; END $$;

      DO $$ BEGIN
        CREATE TYPE followup_status AS ENUM (
          'pending','completed','overdue','rescheduled','cancelled'
        );
      EXCEPTION WHEN duplicate_object THEN NULL; END $$;

      DO $$ BEGIN
        CREATE TYPE activity_type AS ENUM (
          'status_change','comment_added','followup_scheduled',
          'document_uploaded','payment_received','assigned',
          'feasibility_updated','installation_updated','note_added'
        );
      EXCEPTION WHEN duplicate_object THEN NULL; END $$;

      DO $$ BEGIN
        CREATE TYPE commission_type AS ENUM ('percentage','flat');
      EXCEPTION WHEN duplicate_object THEN NULL; END $$;

      DO $$ BEGIN
        CREATE TYPE commission_status AS ENUM (
          'pending','approved','paid','rejected'
        );
      EXCEPTION WHEN duplicate_object THEN NULL; END $$;

      DO $$ BEGIN
        CREATE TYPE txn_status AS ENUM (
          'initiated','success','failed','refunded','chargeback'
        );
      EXCEPTION WHEN duplicate_object THEN NULL; END $$;

      DO $$ BEGIN
        CREATE TYPE field_type AS ENUM (
          'text','number','date','boolean','select','multiselect','url','email'
        );
      EXCEPTION WHEN duplicate_object THEN NULL; END $$;
    `,
  },

  // ── V2-003  Call & Follow-Up Module ──────────────────────────────────────
  {
    name: 'v2_003_follow_ups',
    sql: `
      CREATE TABLE IF NOT EXISTS follow_ups (
        id                UUID            PRIMARY KEY DEFAULT uuid_generate_v4(),
        lead_id           UUID            NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
        assigned_to       UUID            NOT NULL REFERENCES users(id),
        created_by        UUID            NOT NULL REFERENCES users(id),

        followup_type     followup_type   NOT NULL DEFAULT 'call',
        status            followup_status NOT NULL DEFAULT 'pending',

        scheduled_at      TIMESTAMPTZ     NOT NULL,
        completed_at      TIMESTAMPTZ,
        duration_minutes  INTEGER,

        notes             TEXT,
        outcome           TEXT,
        next_action       TEXT,

        -- Auto-reschedule tracking
        reschedule_count  INTEGER         NOT NULL DEFAULT 0,
        rescheduled_from  UUID            REFERENCES follow_ups(id),
        reschedule_reason TEXT,

        -- Reminder flags
        reminder_5min_sent  BOOLEAN       NOT NULL DEFAULT FALSE,
        reminder_30min_sent BOOLEAN       NOT NULL DEFAULT FALSE,

        is_deleted        BOOLEAN         NOT NULL DEFAULT FALSE,
        created_at        TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
        updated_at        TIMESTAMPTZ     NOT NULL DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_fu_lead_id      ON follow_ups(lead_id);
      CREATE INDEX IF NOT EXISTS idx_fu_assigned_to  ON follow_ups(assigned_to);
      CREATE INDEX IF NOT EXISTS idx_fu_status       ON follow_ups(status);
      CREATE INDEX IF NOT EXISTS idx_fu_scheduled_at ON follow_ups(scheduled_at);
      CREATE INDEX IF NOT EXISTS idx_fu_reminders    ON follow_ups(status, scheduled_at)
        WHERE status = 'pending' AND is_deleted = FALSE;
    `,
  },

  // ── V2-004  Lead Timeline / Activity Module ───────────────────────────────
  {
    name: 'v2_004_lead_activities',
    sql: `
      CREATE TABLE IF NOT EXISTS lead_activities (
        id              UUID          PRIMARY KEY DEFAULT uuid_generate_v4(),
        lead_id         UUID          NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
        triggered_by    UUID          REFERENCES users(id),  -- NULL = system/trigger

        activity_type   activity_type NOT NULL,
        title           VARCHAR(255)  NOT NULL,
        description     TEXT,

        old_value       JSONB,
        new_value       JSONB,
        meta            JSONB         DEFAULT '{}'::JSONB,

        ip_address      INET,
        user_agent      TEXT,

        created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_la_lead_id    ON lead_activities(lead_id);
      CREATE INDEX IF NOT EXISTS idx_la_type       ON lead_activities(activity_type);
      CREATE INDEX IF NOT EXISTS idx_la_created_at ON lead_activities(created_at DESC);

      -- ── Activity Attachments ────────────────────────────────────────────
      CREATE TABLE IF NOT EXISTS activity_attachments (
        id            UUID          PRIMARY KEY DEFAULT uuid_generate_v4(),
        activity_id   UUID          NOT NULL REFERENCES lead_activities(id) ON DELETE CASCADE,
        lead_id       UUID          NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
        uploaded_by   UUID          REFERENCES users(id),

        file_name     VARCHAR(255)  NOT NULL,
        file_url      TEXT          NOT NULL,
        file_size     BIGINT,
        mime_type     VARCHAR(100),

        created_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_aa_activity_id ON activity_attachments(activity_id);
      CREATE INDEX IF NOT EXISTS idx_aa_lead_id     ON activity_attachments(lead_id);
    `,
  },

  // ── V2-005  PostgreSQL Trigger: AFTER UPDATE on leads ────────────────────
  {
    name: 'v2_005_leads_trigger',
    sql: `
      -- Function used by the trigger
      CREATE OR REPLACE FUNCTION fn_log_lead_activity()
      RETURNS TRIGGER AS $$
      DECLARE
        v_old   JSONB;
        v_new   JSONB;
        v_title VARCHAR(255);
      BEGIN
        -- Status change detection
        IF OLD.status IS DISTINCT FROM NEW.status THEN
          v_old   := jsonb_build_object('status', OLD.status);
          v_new   := jsonb_build_object('status', NEW.status);
          v_title := 'Status changed from ' || OLD.status || ' to ' || NEW.status;

          INSERT INTO lead_activities
            (lead_id, activity_type, title, old_value, new_value)
          VALUES
            (NEW.id, 'status_change', v_title, v_old, v_new);
        END IF;

        -- Assignment change detection
        IF OLD.assigned_to IS DISTINCT FROM NEW.assigned_to THEN
          INSERT INTO lead_activities
            (lead_id, activity_type, title, old_value, new_value)
          VALUES (
            NEW.id, 'assigned',
            'Lead reassigned',
            jsonb_build_object('assigned_to', OLD.assigned_to),
            jsonb_build_object('assigned_to', NEW.assigned_to)
          );
        END IF;

        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql;

      -- Drop + recreate so re-running migrate is idempotent
      DROP TRIGGER IF EXISTS trg_lead_activity ON leads;

      CREATE TRIGGER trg_lead_activity
        AFTER UPDATE ON leads
        FOR EACH ROW
        EXECUTE FUNCTION fn_log_lead_activity();
    `,
  },

  // ── V2-006  Master Settings ───────────────────────────────────────────────
  {
    name: 'v2_006_master_settings',
    sql: `
      -- Custom field definitions (tenant-level schema extension)
      CREATE TABLE IF NOT EXISTS custom_field_definitions (
        id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
        entity_type   VARCHAR(50) NOT NULL DEFAULT 'lead',
        field_key     VARCHAR(100) NOT NULL,
        field_label   VARCHAR(255) NOT NULL,
        field_type    field_type  NOT NULL DEFAULT 'text',
        options       JSONB,              -- for select/multiselect
        is_required   BOOLEAN     NOT NULL DEFAULT FALSE,
        is_active     BOOLEAN     NOT NULL DEFAULT TRUE,
        sort_order    INTEGER     NOT NULL DEFAULT 0,
        created_by    UUID        REFERENCES users(id),
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE(entity_type, field_key)
      );

      -- Custom field values per lead
      CREATE TABLE IF NOT EXISTS lead_custom_field_values (
        id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
        lead_id         UUID        NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
        field_def_id    UUID        NOT NULL REFERENCES custom_field_definitions(id) ON DELETE CASCADE,
        value_text      TEXT,
        value_number    NUMERIC,
        value_boolean   BOOLEAN,
        value_date      DATE,
        value_json      JSONB,
        created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE(lead_id, field_def_id)
      );

      CREATE INDEX IF NOT EXISTS idx_lcfv_lead_id  ON lead_custom_field_values(lead_id);
      CREATE INDEX IF NOT EXISTS idx_lcfv_field_id ON lead_custom_field_values(field_def_id);

      -- Pipeline stages
      CREATE TABLE IF NOT EXISTS pipeline_stages (
        id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
        name        VARCHAR(100) NOT NULL,
        description TEXT,
        color       VARCHAR(7),   -- hex color
        sort_order  INTEGER     NOT NULL DEFAULT 0,
        is_active   BOOLEAN     NOT NULL DEFAULT TRUE,
        created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      -- Lead scoring rules
      CREATE TABLE IF NOT EXISTS lead_scoring_rules (
        id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
        rule_name     VARCHAR(100) NOT NULL,
        field_key     VARCHAR(100) NOT NULL,
        operator      VARCHAR(20) NOT NULL,  -- eq, gt, lt, contains, in
        value         JSONB       NOT NULL,
        score_delta   INTEGER     NOT NULL DEFAULT 0,
        is_active     BOOLEAN     NOT NULL DEFAULT TRUE,
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      -- Assignment rules (round-robin, territory, load-based)
      CREATE TABLE IF NOT EXISTS assignment_rules (
        id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
        rule_name       VARCHAR(100) NOT NULL,
        conditions      JSONB       NOT NULL DEFAULT '{}'::JSONB,
        assign_to_role  VARCHAR(50),
        assign_to_user  UUID        REFERENCES users(id),
        strategy        VARCHAR(20) NOT NULL DEFAULT 'round_robin', -- round_robin,territory,least_loaded
        is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
        priority        INTEGER     NOT NULL DEFAULT 0,
        created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `,
  },

  // ── V2-007  Role Permissions ──────────────────────────────────────────────
  {
    name: 'v2_007_permissions',
    sql: `
      -- Atomic permission registry
      CREATE TABLE IF NOT EXISTS permissions (
        id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
        module      VARCHAR(50) NOT NULL,
        action      VARCHAR(50) NOT NULL,  -- read, write, delete, export
        description TEXT,
        created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE(module, action)
      );

      -- Role → permission matrix
      CREATE TABLE IF NOT EXISTS role_permissions (
        id             UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
        role           VARCHAR(50) NOT NULL,
        permission_id  UUID        NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
        granted        BOOLEAN     NOT NULL DEFAULT TRUE,
        granted_by     UUID        REFERENCES users(id),
        created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE(role, permission_id)
      );

      -- Module-level access flags
      CREATE TABLE IF NOT EXISTS module_access (
        id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
        role        VARCHAR(50) NOT NULL,
        module      VARCHAR(50) NOT NULL,
        can_access  BOOLEAN     NOT NULL DEFAULT FALSE,
        updated_by  UUID        REFERENCES users(id),
        updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE(role, module)
      );

      -- Financial access flags (read-only sensitive financial data)
      CREATE TABLE IF NOT EXISTS financial_access_flags (
        id                   UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id              UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
        can_view_revenue     BOOLEAN     NOT NULL DEFAULT FALSE,
        can_view_commissions BOOLEAN     NOT NULL DEFAULT FALSE,
        can_export_payments  BOOLEAN     NOT NULL DEFAULT FALSE,
        can_approve_refunds  BOOLEAN     NOT NULL DEFAULT FALSE,
        updated_by           UUID        REFERENCES users(id),
        updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_rp_role   ON role_permissions(role);
      CREATE INDEX IF NOT EXISTS idx_ma_role   ON module_access(role);

      -- Seed base permissions
      INSERT INTO permissions (module, action, description) VALUES
        ('leads',    'read',    'View leads'),
        ('leads',    'write',   'Create/update leads'),
        ('leads',    'delete',  'Delete leads'),
        ('leads',    'export',  'Export lead data'),
        ('reports',  'read',    'View reports'),
        ('reports',  'export',  'Export reports'),
        ('payments', 'read',    'View payment records'),
        ('payments', 'write',   'Record payments'),
        ('settings', 'read',    'View settings'),
        ('settings', 'write',   'Modify settings'),
        ('users',    'read',    'View users'),
        ('users',    'write',   'Create/update users')
      ON CONFLICT (module, action) DO NOTHING;
    `,
  },

  // ── V2-008  Payment Enhancement ──────────────────────────────────────────
  {
    name: 'v2_008_payments',
    sql: `
      -- Enhanced transaction ledger
      CREATE TABLE IF NOT EXISTS payment_transactions (
        id                  UUID          PRIMARY KEY DEFAULT uuid_generate_v4(),
        lead_id             UUID          NOT NULL REFERENCES leads(id) ON DELETE RESTRICT,
        recorded_by         UUID          REFERENCES users(id),

        amount              NUMERIC(12,2) NOT NULL,
        currency            CHAR(3)       NOT NULL DEFAULT 'INR',
        payment_mode        VARCHAR(50)   NOT NULL,
        txn_status          txn_status    NOT NULL DEFAULT 'initiated',

        gateway_txn_id      VARCHAR(200),          -- external reference
        idempotency_key     VARCHAR(200)  UNIQUE,   -- prevent duplicate webhooks
        gateway_response    JSONB,

        webhook_received_at TIMESTAMPTZ,
        webhook_signature   TEXT,

        notes               TEXT,
        created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
        updated_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_pt_lead_id      ON payment_transactions(lead_id);
      CREATE INDEX IF NOT EXISTS idx_pt_gateway_txn  ON payment_transactions(gateway_txn_id);
      CREATE INDEX IF NOT EXISTS idx_pt_status       ON payment_transactions(txn_status);
      CREATE INDEX IF NOT EXISTS idx_pt_idem_key     ON payment_transactions(idempotency_key);

      -- Commission rules (configurable rates per role/package)
      CREATE TABLE IF NOT EXISTS commission_rules (
        id              UUID            PRIMARY KEY DEFAULT uuid_generate_v4(),
        name            VARCHAR(100)    NOT NULL,
        applies_to_role VARCHAR(50)     NOT NULL DEFAULT 'sales',
        package_id      UUID,           -- NULL = all packages
        commission_type commission_type NOT NULL DEFAULT 'percentage',
        rate            NUMERIC(8,4)    NOT NULL,  -- % or flat INR
        min_amount      NUMERIC(12,2),
        max_amount      NUMERIC(12,2),
        is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
        created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
        updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
      );

      -- Commission records
      CREATE TABLE IF NOT EXISTS commissions (
        id              UUID              PRIMARY KEY DEFAULT uuid_generate_v4(),
        transaction_id  UUID              NOT NULL REFERENCES payment_transactions(id) ON DELETE CASCADE,
        lead_id         UUID              NOT NULL REFERENCES leads(id),
        user_id         UUID              NOT NULL REFERENCES users(id),
        rule_id         UUID              REFERENCES commission_rules(id),

        commission_type commission_type   NOT NULL DEFAULT 'percentage',
        rate            NUMERIC(8,4),
        base_amount     NUMERIC(12,2)     NOT NULL,
        commission_amt  NUMERIC(12,2)     NOT NULL,

        status          commission_status NOT NULL DEFAULT 'pending',
        approved_by     UUID              REFERENCES users(id),
        paid_at         TIMESTAMPTZ,
        notes           TEXT,

        created_at      TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
        updated_at      TIMESTAMPTZ       NOT NULL DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_com_user_id ON commissions(user_id);
      CREATE INDEX IF NOT EXISTS idx_com_status  ON commissions(status);
      CREATE INDEX IF NOT EXISTS idx_com_lead_id ON commissions(lead_id);
    `,
  },

  // ── V2-009  Reports caching table ────────────────────────────────────────
  {
    name: 'v2_009_report_cache',
    sql: `
      CREATE TABLE IF NOT EXISTS report_cache (
        id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
        report_type   VARCHAR(50) NOT NULL,
        period        VARCHAR(20) NOT NULL,   -- YYYY-MM or YYYY-Q1
        payload       JSONB       NOT NULL,
        generated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        expires_at    TIMESTAMPTZ NOT NULL,
        UNIQUE(report_type, period)
      );

      CREATE INDEX IF NOT EXISTS idx_rc_type_period ON report_cache(report_type, period);
      CREATE INDEX IF NOT EXISTS idx_rc_expires     ON report_cache(expires_at);
    `,
  },

];

// ═════════════════════════════════════════════════════════════════════════════
// RUNNER
// ═════════════════════════════════════════════════════════════════════════════

const runMigrations = async () => {
  const client = await pool.connect();
  try {
    // Schema version tracking
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations_v2 (
        id         SERIAL       PRIMARY KEY,
        name       VARCHAR(200) NOT NULL UNIQUE,
        applied_at TIMESTAMPTZ  NOT NULL DEFAULT NOW()
      );
    `);

    logger.info(`[MigrateV2] Running ${migrations.length} migration(s)...`);

    for (const migration of migrations) {
      const { rows: existing } = await client.query(
        'SELECT id FROM schema_migrations_v2 WHERE name = $1',
        [migration.name]
      );

      if (existing.length > 0) {
        logger.info(`[MigrateV2] SKIP  ${migration.name} (already applied)`);
        continue;
      }

      try {
        await client.query('BEGIN');
        await client.query(migration.sql);
        await client.query(
          'INSERT INTO schema_migrations_v2 (name) VALUES ($1)',
          [migration.name]
        );
        await client.query('COMMIT');
        logger.info(`[MigrateV2] OK    ${migration.name}`);
      } catch (err) {
        await client.query('ROLLBACK');
        logger.error(`[MigrateV2] FAIL  ${migration.name}`, { error: err.message });
        throw err;
      }
    }

    logger.info('[MigrateV2] ✅ All migrations complete');
  } finally {
    client.release();
    await pool.end();
  }
};

runMigrations().catch((err) => {
  logger.error('[MigrateV2] Fatal migration error', { error: err.message });
  process.exit(1);
});
